# Outil Bas Carbone Avant-Projet (APS/APD)
**Stage OTEIS — Outil d'aide à la conception bas carbone**

Cet outil aide les ingénieurs à comparer des choix techniques et estimer
les impacts carbone/énergie d'un projet dès la phase APS/APD.

---

## Architecture

```
outil-carbone/
├── mcp_server/
│   ├── server.py           ← Serveur MCP (point d'entrée)
│   └── parseur_dossier.py  ← Lecture des dossiers clients
│
├── calcul_carbone/
│   └── moteur_calcul.py    ← Calculs kgCO2, kWh, RE2020
│
├── excel_module/
│   └── excel_handler.py    ← Génération et mise à jour Excel
│
├── frontend/               ← Dashboard React (Étape 4)
├── exports/                ← Export PDF/Excel (Étape 6)
│
├── data/
│   ├── bases/
│   │   └── facteurs_emission.json   ← ADEME/INIES/OTEIS
│   ├── template_calcul.xlsx         ← Template Excel (à créer)
│   └── exemple_dossier_client.json  ← Exemple de dossier
│
├── requirements.txt
└── claude_desktop_config.json  ← Config pour Claude Desktop
```

---

## Installation

```bash
# 1. Créer un environnement virtuel
python -m venv .venv
source .venv/bin/activate  # Linux/Mac
.venv\Scripts\activate     # Windows

# 2. Installer les dépendances
pip install -r requirements.txt

# 3. Tester le serveur MCP
python mcp_server/server.py
```

---

## Configuration Claude Desktop

Copier le contenu de `claude_desktop_config.json` dans :
- **Mac** : `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows** : `%APPDATA%\Claude\claude_desktop_config.json`

Remplacer `/CHEMIN/VERS/outil-carbone` par le chemin réel du projet.

---

## Outils MCP disponibles

| Outil | Description |
|---|---|
| `lire_dossier_client` | Parse PDF/JSON/texte → données structurées |
| `remplir_excel` | Remplit le template Excel automatiquement |
| `calculer_bilan_carbone` | Calcule kgCO2, kWh, conformité RE2020 |
| `comparer_variantes` | Compare plusieurs systèmes techniques |
| `mettre_a_jour_dashboard` | Met à jour le dashboard (IA ou manuel) |
| `exporter_rapport` | Export Excel / PDF / PowerBI |
| `interroger_base` | Recherche dans ADENE, INIES, OTEIS |

---

## Flux de travail type

1. **Déposer le dossier client** dans `data/`
2. **Dans Claude Desktop**, dire :
   > "Analyse le dossier data/mon_projet.json, calcule le bilan carbone et ouvre le dashboard"
3. Claude appelle les outils MCP dans l'ordre :
   - `lire_dossier_client` → parse le dossier
   - `calculer_bilan_carbone` → calcule les bilans
   - `remplir_excel` → génère l'Excel
4. **Le dashboard s'ouvre** avec toutes les valeurs pré-remplies
5. **Modifier manuellement** n'importe quelle valeur directement dans le dashboard
6. **Poser des questions** dans le chat : "Compare PAC air/eau vs chaudière biomasse"

---

## Étapes de développement du stage

- [x] **Étape 1** — Serveur MCP + parseur dossier + moteur calcul
- [ ] **Étape 2** — Template Excel structuré (openpyxl)
- [ ] **Étape 3** — Module calcul carbone avancé (ADENE/INIES)
- [ ] **Étape 4** — Dashboard frontend React (tout éditable)
- [ ] **Étape 5** — Onglet Chat (API Anthropic + contexte projet)
- [ ] **Étape 6** — Export rapport (PDF/Excel/PowerBI)

---

## Sources des données

- **ADEME Base Carbone** v23.1 — facteurs d'émission énergie
- **INIES** — Fiches de Déclaration Environnementale (FDES/PEP)
- **OTEIS** — Retours d'expérience projets internes
- **RE2020** — Arrêté du 4 août 2021 modifié (seuils Ic_énergie)
