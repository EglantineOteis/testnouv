"""
Génère le template Excel structuré pour l'outil bas carbone OTEIS.

Feuilles :
  1. ACCUEIL        — Navigation et légende des couleurs
  2. DONNÉES PROJET — Saisie des infos projet (cellules jaunes éditables)
  3. CALCUL CARBONE — Moteur de calcul avec formules Excel
  4. VARIANTES      — Comparaison jusqu'à 4 variantes
  5. DASHBOARD      — Synthèse visuelle, tout éditable
  6. BASES DONNÉES  — Référentiel ADEME/INIES (consultation)
"""

from openpyxl import Workbook
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side, GradientFill
)
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import ColorScaleRule, CellIsRule, FormulaRule

from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.drawing.image import Image as XLImage
import os

# ─────────────────────────────────────────────
#  Palette de couleurs OTEIS
# ─────────────────────────────────────────────

C = {
    # Fonds
    "vert_fonce":   "1B4332",
    "vert_moyen":   "2D6A4F",
    "vert_clair":   "52B788",
    "vert_pale":    "D8F3DC",
    "vert_saisie":  "B7E4C7",

    "jaune_input":  "FFF9C4",   # cellules saisie utilisateur
    "jaune_bord":   "F9A825",

    "bleu_formule": "E3F2FD",   # cellules avec formule
    "bleu_bord":    "1565C0",
    "bleu_texte":   "0000FF",   # convention : texte bleu = input

    "orange_alerte":"FF6F00",
    "rouge_erreur": "B71C1C",
    "rouge_fond":   "FFEBEE",

    "gris_entete":  "F5F5F5",
    "gris_ligne":   "FAFAFA",
    "gris_bord":    "BDBDBD",

    "blanc":        "FFFFFF",
    "noir":         "000000",
    "texte_sec":    "546E7A",
}

# ─────────────────────────────────────────────
#  Styles réutilisables
# ─────────────────────────────────────────────

def thin_border(color="BDBDBD"):
    s = Side(style="thin", color=color)
    return Border(left=s, right=s, top=s, bottom=s)

def bottom_border(color="BDBDBD"):
    return Border(bottom=Side(style="thin", color=color))

def fill(hex_color):
    return PatternFill("solid", fgColor=hex_color)

def font(bold=False, size=11, color="000000", italic=False):
    return Font(name="Arial", bold=bold, size=size, color=color, italic=italic)

def align(h="left", v="center", wrap=False):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap)

def style_titre_section(ws, row, col, texte, largeur_merge=None):
    cell = ws.cell(row=row, column=col, value=texte)
    cell.font = Font(name="Arial", bold=True, size=11, color=C["blanc"])
    cell.fill = fill(C["vert_moyen"])
    cell.alignment = align("left", "center")
    cell.border = thin_border(C["vert_clair"])
    if largeur_merge:
        ws.merge_cells(
            start_row=row, start_column=col,
            end_row=row, end_column=col + largeur_merge - 1
        )
    ws.row_dimensions[row].height = 22
    return cell

def style_entete_col(ws, row, col, texte):
    cell = ws.cell(row=row, column=col, value=texte)
    cell.font = Font(name="Arial", bold=True, size=10, color=C["blanc"])
    cell.fill = fill(C["vert_fonce"])
    cell.alignment = align("center", "center")
    cell.border = thin_border(C["vert_moyen"])
    ws.row_dimensions[row].height = 20
    return cell

def style_input(ws, row, col, valeur=None):
    """Cellule jaune = saisie utilisateur."""
    cell = ws.cell(row=row, column=col, value=valeur)
    cell.font = Font(name="Arial", size=10, color=C["bleu_texte"])
    cell.fill = fill(C["jaune_input"])
    cell.alignment = align("left", "center")
    cell.border = thin_border(C["jaune_bord"])
    return cell

def style_formule(ws, row, col, formule=None):
    """Cellule bleue = calculée par formule."""
    cell = ws.cell(row=row, column=col, value=formule)
    cell.font = Font(name="Arial", size=10, color=C["noir"])
    cell.fill = fill(C["bleu_formule"])
    cell.alignment = align("right", "center")
    cell.border = thin_border(C["bleu_bord"])
    return cell

def style_label(ws, row, col, texte):
    cell = ws.cell(row=row, column=col, value=texte)
    cell.font = Font(name="Arial", size=10, color=C["texte_sec"])
    cell.alignment = align("left", "center")
    cell.border = bottom_border(C["gris_bord"])
    return cell

def style_resultat(ws, row, col, valeur=None, bold=False):
    cell = ws.cell(row=row, column=col, value=valeur)
    cell.font = Font(name="Arial", bold=bold, size=10 if not bold else 11, color=C["vert_fonce"])
    cell.fill = fill(C["vert_pale"])
    cell.alignment = align("right", "center")
    cell.border = thin_border(C["vert_clair"])
    return cell


# ─────────────────────────────────────────────
#  FEUILLE 1 — ACCUEIL
# ─────────────────────────────────────────────

def creer_accueil(ws):
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 30
    ws.column_dimensions["C"].width = 50
    ws.column_dimensions["D"].width = 20
    ws.row_dimensions[1].height = 10

    # Bandeau titre
    ws.merge_cells("B2:D2")
    c = ws["B2"]
    c.value = "OUTIL BAS CARBONE — APS/APD"
    c.font = Font(name="Arial", bold=True, size=18, color=C["blanc"])
    c.fill = fill(C["vert_fonce"])
    c.alignment = align("center", "center")
    ws.row_dimensions[2].height = 45

    ws.merge_cells("B3:D3")
    c = ws["B3"]
    c.value = "Outil d'aide à la conception bas carbone — OTEIS Group"
    c.font = Font(name="Arial", size=11, color=C["vert_clair"], italic=True)
    c.fill = fill(C["vert_fonce"])
    c.alignment = align("center", "center")
    ws.row_dimensions[3].height = 22

    # Navigation
    ws.row_dimensions[5].height = 8
    style_titre_section(ws, 6, 2, "  NAVIGATION", 3)

    nav = [
        ("📋  DONNÉES PROJET",  "Saisir les caractéristiques du projet",       "Onglet vert — cellules jaunes"),
        ("🔢  CALCUL CARBONE",  "Bilan kgCO2eq/m².an et kWh_ep/m².an",        "Formules automatiques"),
        ("🔄  VARIANTES",       "Comparer jusqu'à 4 systèmes techniques",      "Tableau comparatif"),
        ("📊  DASHBOARD",       "Synthèse visuelle — tout modifiable",          "Vue projet complète"),
        ("📚  BASES DONNÉES",   "Référentiel ADEME / INIES / OTEIS",           "Consultation uniquement"),
    ]
    for i, (nom, desc, note) in enumerate(nav, start=7):
        ws.row_dimensions[i].height = 20
        c = ws.cell(row=i, column=2, value=nom)
        c.font = Font(name="Arial", bold=True, size=10, color=C["vert_fonce"])
        c.fill = fill(C["vert_pale"])
        c.alignment = align("left", "center")
        c.border = thin_border(C["vert_clair"])

        c2 = ws.cell(row=i, column=3, value=desc)
        c2.font = Font(name="Arial", size=10)
        c2.alignment = align("left", "center")
        c2.border = bottom_border()

        c3 = ws.cell(row=i, column=4, value=note)
        c3.font = Font(name="Arial", size=9, color=C["texte_sec"], italic=True)
        c3.alignment = align("left", "center")
        c3.border = bottom_border()

    # Légende couleurs
    ws.row_dimensions[14].height = 8
    style_titre_section(ws, 15, 2, "  LÉGENDE DES COULEURS", 3)

    legende = [
        (C["jaune_input"],  C["bleu_texte"],  "Cellule jaune / texte bleu",  "Valeur à saisir — MODIFIABLE"),
        (C["bleu_formule"], C["noir"],         "Cellule bleue",               "Formule automatique — ne pas modifier"),
        (C["vert_pale"],    C["vert_fonce"],   "Cellule verte",               "Résultat calculé"),
        (C["rouge_fond"],   C["rouge_erreur"], "Cellule rouge",               "Alerte ou non-conformité RE2020"),
        (C["blanc"],        C["texte_sec"],    "Cellule blanche",             "Information / label"),
    ]
    for i, (bg, fg, label, desc) in enumerate(legende, start=16):
        ws.row_dimensions[i].height = 20
        c = ws.cell(row=i, column=2, value=f"  {label}")
        c.font = Font(name="Arial", size=10, color=fg)
        c.fill = fill(bg)
        c.alignment = align("left", "center")
        c.border = thin_border(C["gris_bord"])

        c2 = ws.cell(row=i, column=3, value=desc)
        c2.font = Font(name="Arial", size=10, color=C["texte_sec"])
        c2.alignment = align("left", "center")
        c2.border = bottom_border()

    # Sources
    ws.row_dimensions[23].height = 8
    style_titre_section(ws, 24, 2, "  SOURCES DES DONNÉES", 3)
    sources = [
        "ADEME — Base Carbone v23.1 (facteurs d'émission énergie)",
        "INIES — Données environnementales FDES/PEP (matériaux, systèmes)",
        "OTEIS — Retours d'expérience projets internes",
        "RE2020 — Arrêté du 4 août 2021 modifié (seuils Ic_énergie)",
    ]
    for i, s in enumerate(sources, start=25):
        ws.row_dimensions[i].height = 18
        c = ws.cell(row=i, column=2, value=f"  • {s}")
        c.font = Font(name="Arial", size=9, color=C["texte_sec"])
        ws.merge_cells(start_row=i, start_column=2, end_row=i, end_column=4)

    ws.row_dimensions[30].height = 8
    c = ws.cell(row=31, column=2,
        value="⚠  Toutes les valeurs calculées sont des estimations APS/APD. "
              "Vérification obligatoire lors des phases suivantes.")
    c.font = Font(name="Arial", size=9, color=C["orange_alerte"], italic=True)
    ws.merge_cells("B31:D31")


# ─────────────────────────────────────────────
#  FEUILLE 2 — DONNÉES PROJET
# ─────────────────────────────────────────────

def creer_donnees_projet(ws):
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 32
    ws.column_dimensions["C"].width = 36
    ws.column_dimensions["D"].width = 16
    ws.column_dimensions["E"].width = 28

    # En-tête
    ws.merge_cells("B1:E1")
    c = ws["B1"]
    c.value = "DONNÉES PROJET"
    c.font = Font(name="Arial", bold=True, size=14, color=C["blanc"])
    c.fill = fill(C["vert_fonce"])
    c.alignment = align("center", "center")
    ws.row_dimensions[1].height = 35

    ws.merge_cells("B2:E2")
    c = ws["B2"]
    c.value = "Remplir les cellules en jaune — les valeurs bleues sont calculées automatiquement"
    c.font = Font(name="Arial", size=9, color=C["jaune_bord"], italic=True)
    c.fill = fill(C["vert_moyen"])
    c.alignment = align("center", "center")
    ws.row_dimensions[2].height = 18

    # ── BLOC 1 : Identité projet
    style_titre_section(ws, 4, 2, "  1 — IDENTITÉ DU PROJET", 4)

    champs_id = [
        ("Nom du projet",            "C5",  "Grands Moulins — Bureaux R+5"),
        ("Maître d'ouvrage",         "C6",  ""),
        ("Localisation (ville, dpt)","C7",  "Rouen (76)"),
        ("Type de bâtiment",         "C8",  "Bureaux"),
        ("Adresse / référence",      "C9",  ""),
        ("Numéro d'affaire OTEIS",   "C10", ""),
        ("Ingénieur responsable",    "C11", ""),
        ("Date de mise à jour",      "C12", ""),
    ]
    for row, (label, ref, exemple) in enumerate(champs_id, start=5):
        ws.row_dimensions[row].height = 20
        style_label(ws, row, 2, label)
        style_input(ws, row, 3)
        c_ex = ws.cell(row=row, column=5, value=f"ex : {exemple}" if exemple else "")
        c_ex.font = Font(name="Arial", size=8, color=C["texte_sec"], italic=True)

    # ── BLOC 2 : Données techniques
    ws.row_dimensions[14].height = 8
    style_titre_section(ws, 15, 2, "  2 — DONNÉES TECHNIQUES", 4)

    tech = [
        ("Surface plancher (m²)",     "C16", "m²",   "ex : 3200"),
        ("Nombre de niveaux",          "C17", "niv.", "ex : 5"),
        ("Zone climatique",            "C18", "",     "H1 / H2 / H3"),
        ("Année de livraison prévue",  "C19", "",     "ex : 2026"),
        ("Surface vitrée (%)",         "C20", "%",    "ex : 40"),
        ("Hauteur sous plafond (m)",   "C21", "m",    "ex : 2.70"),
    ]
    for row, (label, ref, unite, ex) in enumerate(tech, start=16):
        ws.row_dimensions[row].height = 20
        style_label(ws, row, 2, label)
        style_input(ws, row, 3)
        ws.cell(row=row, column=4, value=unite).font = Font(name="Arial", size=9, color=C["texte_sec"])
        ws.cell(row=row, column=5, value=f"ex : {ex}").font = Font(name="Arial", size=8, color=C["texte_sec"], italic=True)

    # Validation zone climatique
    dv_zone = DataValidation(type="list", formula1='"H1,H2,H3"', allow_blank=True)
    dv_zone.sqref = "C18"
    ws.add_data_validation(dv_zone)

    # ── BLOC 3 : Systèmes CVC
    ws.row_dimensions[24].height = 8
    style_titre_section(ws, 25, 2, "  3 — SYSTÈMES CVC", 4)

    cvc_systemes = [
        "PAC air/eau", "PAC réversible", "PAC thermodynamique", "PAC géothermique",
        "Chaudière gaz", "Chaudière biomasse", "Réseau de chaleur urbain",
        "double flux", "simple flux", "VRV/VRF", "Plancher chauffant"
    ]
    liste_cvc = f'"{",".join(cvc_systemes)}"'

    cvc_champs = [
        ("Système de chauffage",    "C26"),
        ("Système de refroidissement","C27"),
        ("Ventilation",             "C28"),
        ("Production ECS",          "C29"),
    ]
    for row, (label, ref) in enumerate(cvc_champs, start=26):
        ws.row_dimensions[row].height = 20
        style_label(ws, row, 2, label)
        c = style_input(ws, row, 3)
        dv = DataValidation(type="list", formula1=liste_cvc, allow_blank=True)
        dv.sqref = f"C{row}"
        ws.add_data_validation(dv)
        ws.cell(row=row, column=5, value="← liste déroulante").font = Font(
            name="Arial", size=8, color=C["texte_sec"], italic=True)

    # ── BLOC 4 : ENR
    ws.row_dimensions[32].height = 8
    style_titre_section(ws, 33, 2, "  4 — ÉNERGIES RENOUVELABLES (ENR)", 4)

    enr_champs = [
        ("Photovoltaïque",     "C34", "% toiture équipée", "ex : 40"),
        ("Solaire thermique",  "C35", "% toiture équipée", "ex : 20"),
        ("Géothermie",         "C36", "puissance (kW)",    "ex : 0"),
    ]
    for row, (label, ref, unite, ex) in enumerate(enr_champs, start=34):
        ws.row_dimensions[row].height = 20
        style_label(ws, row, 2, label)
        style_input(ws, row, 3, 0)
        ws.cell(row=row, column=4, value=unite).font = Font(name="Arial", size=9, color=C["texte_sec"])
        ws.cell(row=row, column=5, value=f"ex : {ex}").font = Font(name="Arial", size=8, color=C["texte_sec"], italic=True)

    # ── BLOC 5 : Isolation
    ws.row_dimensions[39].height = 8
    style_titre_section(ws, 40, 2, "  5 — ISOLATION", 4)

    # Sous-en-têtes
    for col, txt in [(2, "Paroi"), (3, "Matériau"), (4, "Épaisseur (cm)")]:
        style_entete_col(ws, 41, col, txt)

    mat_isolants = [
        "laine de roche", "laine de verre", "polystyrène", "polyuréthane",
        "ouate cellulose", "liège", "chanvre", "laine bois", "paille"
    ]
    liste_mat = f'"{",".join(mat_isolants)}"'

    parois = [("Murs extérieurs", "C42", "D42"), ("Toiture / terrasse", "C43", "D43"),
              ("Plancher bas", "C44", "D44")]
    for row, (label, cmat, cep) in enumerate(parois, start=42):
        ws.row_dimensions[row].height = 20
        style_label(ws, row, 2, label)
        c = style_input(ws, row, 3)
        c2 = style_input(ws, row, 4, 20)
        dv = DataValidation(type="list", formula1=liste_mat, allow_blank=True)
        dv.sqref = f"C{row}"
        ws.add_data_validation(dv)

    # ── BLOC 6 : Menuiseries
    ws.row_dimensions[47].height = 8
    style_titre_section(ws, 48, 2, "  6 — MENUISERIES", 4)

    men = [
        ("Type de vitrage",        "C49", "",     "double vitrage DIR / triple"),
        ("Uw — coeff. de paroi",   "C50", "W/m²K","ex : 1.1"),
        ("Sw — facteur solaire",   "C51", "",     "ex : 0.36"),
    ]
    for row, (label, ref, unite, ex) in enumerate(men, start=49):
        ws.row_dimensions[row].height = 20
        style_label(ws, row, 2, label)
        style_input(ws, row, 3)
        ws.cell(row=row, column=4, value=unite).font = Font(name="Arial", size=9, color=C["texte_sec"])
        ws.cell(row=row, column=5, value=f"ex : {ex}").font = Font(name="Arial", size=8, color=C["texte_sec"], italic=True)

    # Freeze panes
    ws.freeze_panes = "B3"


# ─────────────────────────────────────────────
#  FEUILLE 3 — CALCUL CARBONE
# ─────────────────────────────────────────────

def creer_calcul_carbone(ws, ws_dp_name="DONNÉES PROJET", ws_bd_name="BASES DONNÉES"):
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 38
    ws.column_dimensions["C"].width = 22
    ws.column_dimensions["D"].width = 16
    ws.column_dimensions["E"].width = 22
    ws.column_dimensions["F"].width = 26

    # En-tête
    ws.merge_cells("B1:F1")
    c = ws["B1"]
    c.value = "CALCUL CARBONE — BILAN kgCO2eq & kWh_ep"
    c.font = Font(name="Arial", bold=True, size=14, color=C["blanc"])
    c.fill = fill(C["vert_fonce"])
    c.alignment = align("center", "center")
    ws.row_dimensions[1].height = 35

    ws.merge_cells("B2:F2")
    c = ws["B2"]
    c.value = (
        "Les cellules bleues sont calculées automatiquement.  "
        "Cellules jaunes = valeurs ajustables manuellement."
    )
    c.font = Font(name="Arial", size=9, color=C["jaune_bord"], italic=True)
    c.fill = fill(C["vert_moyen"])
    c.alignment = align("center", "center")
    ws.row_dimensions[2].height = 18

    # ── Rappel données projet (liens)
    style_titre_section(ws, 4, 2, "  RAPPEL DONNÉES PROJET", 5)
    rappels = [
        ("Nom projet",       f"='DONNÉES PROJET'!C5"),
        ("Type bâtiment",    f"='DONNÉES PROJET'!C8"),
        ("Surface (m²)",     f"='DONNÉES PROJET'!C16"),
        ("Zone climatique",  f"='DONNÉES PROJET'!C18"),
        ("Année livraison",  f"='DONNÉES PROJET'!C19"),
    ]
    for i, (label, formule) in enumerate(rappels, start=5):
        ws.row_dimensions[i].height = 18
        style_label(ws, i, 2, label)
        c = style_formule(ws, i, 3, formule)
        c.font = Font(name="Arial", size=10, color="008000")  # vert = lien inter-feuille

    # ── BLOC Ic_énergie
    ws.row_dimensions[12].height = 8
    style_titre_section(ws, 13, 2, "  IMPACT CARBONE ÉNERGIE (Ic_énergie)", 5)

    # En-têtes colonnes
    for col, txt in [(2,"Poste"),(3,"Système"),(4,"kWh_ep/m².an"),(5,"kgCO2eq/m².an"),(6,"Source")]:
        style_entete_col(ws, 14, col, txt)

    # Lignes postes énergie (valeurs ajustables manuellement)
    postes_energie = [
        ("Chauffage",       "='DONNÉES PROJET'!C26", 45,   2.18),
        ("Refroidissement", "='DONNÉES PROJET'!C27", 18,   0.87),
        ("Ventilation",     "='DONNÉES PROJET'!C28", 8,    0.39),
        ("ECS",             "='DONNÉES PROJET'!C29", 12,   0.58),
        ("Éclairage",       "—",                      20,   0.97),
        ("Auxiliaires",     "—",                      8,    0.39),
    ]
    for i, (poste, sys_formule, kwh_defaut, co2_defaut) in enumerate(postes_energie, start=15):
        ws.row_dimensions[i].height = 20
        style_label(ws, i, 2, poste)
        c_sys = ws.cell(row=i, column=3, value=sys_formule)
        c_sys.font = Font(name="Arial", size=10, color="008000")
        c_sys.alignment = align("left", "center")
        c_sys.border = bottom_border()

        c_kwh = style_input(ws, i, 4, kwh_defaut)
        c_kwh.number_format = "0.0"

        c_co2 = style_formule(ws, i, 5, f"=D{i}*0.0485")
        c_co2.number_format = "0.00"

        ws.cell(row=i, column=6, value="ADEME / INIES").font = Font(
            name="Arial", size=9, color=C["texte_sec"], italic=True)

    # TOTAL Ic_énergie
    ws.row_dimensions[21].height = 22
    ws.merge_cells("B21:D21")
    c = ws["B21"]
    c.value = "TOTAL Ic_énergie (kgCO2eq/m².an)"
    c.font = Font(name="Arial", bold=True, size=11, color=C["vert_fonce"])
    c.fill = fill(C["vert_pale"])
    c.alignment = align("left", "center")
    c.border = thin_border(C["vert_clair"])

    c_tot = style_resultat(ws, 21, 5, "=SUM(E15:E20)", bold=True)
    c_tot.number_format = "0.00"

    ws.cell(row=21, column=6, value='← "Ic_énergie" RE2020').font = Font(
        name="Arial", size=9, color=C["vert_moyen"], italic=True, bold=True)

    # ── BLOC Seuils RE2020
    ws.row_dimensions[24].height = 8
    style_titre_section(ws, 25, 2, "  CONFORMITÉ RE2020 — Ic_énergie", 5)

    for col, txt in [(2,"Seuil"),(3,"Valeur limite (kgCO2/m²/an)"),(4,"Ic projet"),(5,"Résultat"),(6,"Marge")]:
        style_entete_col(ws, 26, col, txt)

    seuils_bureaux = [
        ("Seuil 2022", 6.0),
        ("Seuil 2025", 5.0),
        ("Seuil 2028", 4.0),
        ("Seuil 2031", 3.0),
    ]
    for i, (label, seuil) in enumerate(seuils_bureaux, start=27):
        ws.row_dimensions[i].height = 20
        style_label(ws, i, 2, label)
        c_s = style_input(ws, i, 3, seuil)
        c_s.number_format = "0.00"

        c_ic = style_formule(ws, i, 4, "=$E$21")
        c_ic.number_format = "0.00"

        # Résultat conforme / non conforme
        c_res = ws.cell(row=i, column=5)
        c_res.value = f'=IF(E21<=C{i},"✓  CONFORME","✗  NON CONFORME")'
        c_res.font = Font(name="Arial", size=10, bold=True)
        c_res.alignment = align("center", "center")
        c_res.border = thin_border()

        # Marge
        c_marge = style_formule(ws, i, 6, f"=C{i}-E21")
        c_marge.number_format = '0.00" kgCO2"'

    # Mise en forme conditionnelle RE2020
    from openpyxl.formatting.rule import CellIsRule
    green_fill = PatternFill(start_color="C8E6C9", end_color="C8E6C9", fill_type="solid")
    red_fill   = PatternFill(start_color="FFCDD2", end_color="FFCDD2", fill_type="solid")
    ws.conditional_formatting.add(
        "E27:E30",
        CellIsRule(operator="lessThanOrEqual", formula=["C27"], fill=green_fill)
    )
    ws.conditional_formatting.add(
        "E27:E30",
        CellIsRule(operator="greaterThan", formula=["C27"], fill=red_fill)
    )

    # ── BLOC Ic_bâtiment
    ws.row_dimensions[33].height = 8
    style_titre_section(ws, 34, 2, "  IMPACT CARBONE BÂTIMENT (Ic_bâtiment)", 5)

    for col, txt in [(2,"Poste"),(3,"Matériau / Système"),(4,"Quantité ou m²"),(5,"kgCO2eq/m².an"),(6,"Source")]:
        style_entete_col(ws, 35, col, txt)

    postes_bat = [
        ("Structure béton",       "",   0.0, "INIES — béton C30/37"),
        ("Isolation murs",        "='DONNÉES PROJET'!C42", 0.0, "INIES"),
        ("Isolation toiture",     "='DONNÉES PROJET'!C43", 0.0, "INIES"),
        ("Isolation plancher",    "='DONNÉES PROJET'!C44", 0.0, "INIES"),
        ("Menuiseries",           "='DONNÉES PROJET'!C49", 0.0, "INIES"),
        ("CVC — fabrication",     "='DONNÉES PROJET'!C26", 2.1, "INIES"),
        ("Équipements électriques","",  0.8, "INIES"),
    ]
    for i, (poste, mat, co2, src) in enumerate(postes_bat, start=36):
        ws.row_dimensions[i].height = 20
        style_label(ws, i, 2, poste)

        c_mat = ws.cell(row=i, column=3, value=mat)
        c_mat.font = Font(name="Arial", size=10, color="008000" if mat.startswith("=") else C["bleu_texte"])
        c_mat.fill = fill(C["jaune_input"] if not mat.startswith("=") else C["bleu_formule"])
        c_mat.alignment = align("left", "center")
        c_mat.border = bottom_border()

        c_co2 = style_input(ws, i, 5, co2)
        c_co2.number_format = "0.00"

        ws.cell(row=i, column=6, value=src).font = Font(
            name="Arial", size=9, color=C["texte_sec"], italic=True)

    # Total Ic_bâtiment
    ws.row_dimensions[43].height = 22
    ws.merge_cells("B43:D43")
    c = ws["B43"]
    c.value = "TOTAL Ic_bâtiment (kgCO2eq/m².an)"
    c.font = Font(name="Arial", bold=True, size=11, color=C["vert_fonce"])
    c.fill = fill(C["vert_pale"])
    c.alignment = align("left", "center")
    c.border = thin_border(C["vert_clair"])

    c_tot2 = style_resultat(ws, 43, 5, "=SUM(E36:E42)", bold=True)
    c_tot2.number_format = "0.00"

    # ── BILAN FINAL
    ws.row_dimensions[46].height = 8
    style_titre_section(ws, 47, 2, "  BILAN GLOBAL", 5)

    bilan = [
        ("Ic_énergie (kgCO2eq/m².an)",   "=E21",  "kgCO2eq/m².an"),
        ("Ic_bâtiment (kgCO2eq/m².an)",  "=E43",  "kgCO2eq/m².an"),
        ("Consommation Ep (kWh_ep/m².an)","=SUM(D15:D20)", "kWh_ep/m².an"),
        ("Ic TOTAL (kgCO2eq/m².an)",      "=E21+E43", "kgCO2eq/m².an"),
        ("Ic TOTAL projet (tCO2)",         "=(E21+E43)*'DONNÉES PROJET'!C16/1000", "tCO2"),
    ]
    for i, (label, formule, unite) in enumerate(bilan, start=48):
        ws.row_dimensions[i].height = 22
        bold = (i == 51)
        ws.merge_cells(start_row=i, start_column=2, end_row=i, end_column=3)
        c = ws.cell(row=i, column=2, value=label)
        c.font = Font(name="Arial", bold=bold, size=11 if bold else 10, color=C["vert_fonce"])
        c.fill = fill(C["vert_pale"])
        c.alignment = align("left", "center")
        c.border = thin_border(C["vert_clair"])

        c_val = style_resultat(ws, i, 4, formule, bold=bold)
        c_val.number_format = "0.00"

        ws.cell(row=i, column=5, value=unite).font = Font(
            name="Arial", size=9, color=C["texte_sec"])

    ws.freeze_panes = "B3"


# ─────────────────────────────────────────────
#  FEUILLE 4 — VARIANTES
# ─────────────────────────────────────────────

def creer_variantes(ws):
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 32
    for col in ["C","D","E","F"]:
        ws.column_dimensions[col].width = 22

    ws.merge_cells("B1:F1")
    c = ws["B1"]
    c.value = "COMPARAISON DE VARIANTES TECHNIQUES"
    c.font = Font(name="Arial", bold=True, size=14, color=C["blanc"])
    c.fill = fill(C["vert_fonce"])
    c.alignment = align("center", "center")
    ws.row_dimensions[1].height = 35

    ws.merge_cells("B2:F2")
    c = ws["B2"]
    c.value = "Saisir les valeurs de chaque variante — la meilleure variante est mise en vert automatiquement"
    c.font = Font(name="Arial", size=9, color=C["jaune_bord"], italic=True)
    c.fill = fill(C["vert_moyen"])
    c.alignment = align("center", "center")
    ws.row_dimensions[2].height = 18

    # En-têtes variantes
    ws.row_dimensions[4].height = 28
    style_label(ws, 4, 2, "CRITÈRE")
    for col, v in enumerate(["VARIANTE A", "VARIANTE B", "VARIANTE C", "VARIANTE D"], start=3):
        c = ws.cell(row=4, column=col, value=v)
        c.font = Font(name="Arial", bold=True, size=11, color=C["blanc"])
        c.fill = fill(C["vert_moyen"])
        c.alignment = align("center", "center")
        c.border = thin_border(C["vert_clair"])

    # Noms des variantes
    ws.row_dimensions[5].height = 22
    style_label(ws, 5, 2, "Nom de la variante")
    for col in [3, 4, 5, 6]:
        style_input(ws, 5, col, "À saisir")

    # Sections
    sections = [
        ("  SYSTÈMES CVC", [
            ("Chauffage",          6),
            ("Refroidissement",    7),
            ("Ventilation",        8),
            ("ECS",                9),
        ]),
        ("  ÉNERGIES RENOUVELABLES", [
            ("ENR (type)",         11),
            ("% toiture PV",       12),
        ]),
        ("  RÉSULTATS CARBONE (kgCO2eq/m².an)", [
            ("Ic_énergie",         14),
            ("Ic_bâtiment",        15),
            ("Ic_total",           16),
        ]),
        ("  RÉSULTATS ÉNERGIE", [
            ("Conso. kWh_ep/m².an",18),
            ("Conso. kWh_ef/m².an",19),
        ]),
        ("  CONFORMITÉ RE2020", [
            ("Seuil 2022 atteint ?", 21),
            ("Seuil 2025 atteint ?", 22),
            ("Niveau max atteint",   23),
        ]),
        ("  COÛT ESTIMATIF", [
            ("Surcoût vs base (€/m²)", 25),
            ("Note globale /10",       26),
        ]),
    ]

    row = 6
    for titre_section, champs in sections:
        style_titre_section(ws, row, 2, titre_section, 5)
        row += 1
        for label, _ in champs:
            ws.row_dimensions[row].height = 20
            style_label(ws, row, 2, label)
            for col in [3, 4, 5, 6]:
                style_input(ws, row, col)
            row += 1
        row += 1  # ligne vide entre sections

    # Ligne recommandation
    ws.row_dimensions[row + 1].height = 8
    style_titre_section(ws, row + 2, 2, "  RECOMMANDATION IA", 5)
    ws.row_dimensions[row + 3].height = 60
    ws.merge_cells(
        start_row=row + 3, start_column=2,
        end_row=row + 3, end_column=6
    )
    c = ws.cell(row=row + 3, column=2)
    c.value = "← Zone de commentaire IA — remplie automatiquement par l'analyse"
    c.font = Font(name="Arial", size=10, color=C["texte_sec"], italic=True)
    c.fill = fill(C["vert_pale"])
    c.alignment = align("left", "top", wrap=True)
    c.border = thin_border(C["vert_clair"])

    ws.freeze_panes = "C5"


# ─────────────────────────────────────────────
#  FEUILLE 5 — DASHBOARD
# ─────────────────────────────────────────────

def creer_dashboard(ws):
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 28
    ws.column_dimensions["C"].width = 20
    ws.column_dimensions["D"].width = 14
    ws.column_dimensions["E"].width = 28
    ws.column_dimensions["F"].width = 20
    ws.column_dimensions["G"].width = 14

    # Bandeau
    ws.merge_cells("B1:G1")
    c = ws["B1"]
    c.value = "DASHBOARD — SYNTHÈSE PROJET"
    c.font = Font(name="Arial", bold=True, size=16, color=C["blanc"])
    c.fill = fill(C["vert_fonce"])
    c.alignment = align("center", "center")
    ws.row_dimensions[1].height = 40

    ws.merge_cells("B2:G2")
    c = ws["B2"]
    c.value = "Toutes les valeurs de ce dashboard sont modifiables manuellement — les modifications sont tracées"
    c.font = Font(name="Arial", size=9, color=C["jaune_bord"], italic=True)
    c.fill = fill(C["vert_moyen"])
    c.alignment = align("center", "center")
    ws.row_dimensions[2].height = 18

    # ── Bloc identité (lié à DONNÉES PROJET)
    ws.row_dimensions[4].height = 8
    style_titre_section(ws, 5, 2, "  IDENTITÉ DU PROJET", 6)

    id_champs = [
        ("Projet",          f"='DONNÉES PROJET'!C5",  "E6",  "Maître d'ouvrage",  f"='DONNÉES PROJET'!C6"),
        ("Localisation",    f"='DONNÉES PROJET'!C7",  "E7",  "Type",              f"='DONNÉES PROJET'!C8"),
        ("Surface (m²)",    f"='DONNÉES PROJET'!C16", "E8",  "Zone climatique",   f"='DONNÉES PROJET'!C18"),
        ("Livraison",       f"='DONNÉES PROJET'!C19", "E9",  "Ingénieur",         f"='DONNÉES PROJET'!C11"),
    ]
    for row, (l1, v1, ref2, l2, v2) in enumerate(id_champs, start=6):
        ws.row_dimensions[row].height = 20
        style_label(ws, row, 2, l1)
        c = style_formule(ws, row, 3, v1)
        c.font = Font(name="Arial", size=10, color="008000")
        style_label(ws, row, 5, l2)
        c2 = style_formule(ws, row, 6, v2)
        c2.font = Font(name="Arial", size=10, color="008000")

    # ── KPIs carbone
    ws.row_dimensions[12].height = 8
    style_titre_section(ws, 13, 2, "  INDICATEURS CARBONE & ÉNERGIE", 6)

    for col, txt in [(2,"Indicateur"),(3,"Valeur calculée"),(4,"Unité"),(5,"Valeur ajustée"),(6,"Unité"),(7,"Source")]:
        style_entete_col(ws, 14, col, txt)

    kpis = [
        ("Ic_énergie",           "='CALCUL CARBONE'!E21",             "kgCO2/m².an"),
        ("Ic_bâtiment",          "='CALCUL CARBONE'!E43",             "kgCO2/m².an"),
        ("Ic_total",             "='CALCUL CARBONE'!E21+'CALCUL CARBONE'!E43", "kgCO2/m².an"),
        ("Consommation Ep",      "=SUM('CALCUL CARBONE'!D15:D20)",    "kWh_ep/m².an"),
        ("Consommation Ef",      "=SUM('CALCUL CARBONE'!D15:D20)/2.3","kWh_ef/m².an"),
        ("Ic total projet",      "=('CALCUL CARBONE'!E21+'CALCUL CARBONE'!E43)*'DONNÉES PROJET'!C16/1000", "tCO2"),
    ]
    for i, (label, formule, unite) in enumerate(kpis, start=15):
        ws.row_dimensions[i].height = 22
        style_label(ws, i, 2, label)

        c_calc = style_formule(ws, i, 3, formule)
        c_calc.number_format = "0.00"
        c_calc.font = Font(name="Arial", size=10, color="008000")

        ws.cell(row=i, column=4, value=unite).font = Font(name="Arial", size=9, color=C["texte_sec"])

        # Colonne "valeur ajustée" = jaune, liée à la calculée par défaut
        c_adj = style_input(ws, i, 5, f"=C{i}")
        c_adj.number_format = "0.00"

        ws.cell(row=i, column=6, value=unite).font = Font(name="Arial", size=9, color=C["texte_sec"])
        ws.cell(row=i, column=7, value="IA / Manuel").font = Font(
            name="Arial", size=8, color=C["texte_sec"], italic=True)

    # ── RE2020
    ws.row_dimensions[23].height = 8
    style_titre_section(ws, 24, 2, "  CONFORMITÉ RE2020", 6)

    for col, txt in [(2,"Seuil"),(3,"Limite"),(4,"Ic projet"),(5,"Statut"),(6,"Marge"),(7,"")]:
        style_entete_col(ws, 25, col, txt)

    seuils = [("2022", 6.0), ("2025", 5.0), ("2028", 4.0), ("2031", 3.0)]
    for i, (annee, seuil) in enumerate(seuils, start=26):
        ws.row_dimensions[i].height = 20
        style_label(ws, i, 2, f"RE2020 — {annee}")
        c_s = style_input(ws, i, 3, seuil)
        c_s.number_format = "0.00"

        c_ic = style_formule(ws, i, 4, "=$E$15")
        c_ic.number_format = "0.00"

        c_res = ws.cell(row=i, column=5)
        c_res.value = f'=IF(E15<=C{i},"✓  CONFORME","✗  NON CONFORME")'
        c_res.font = Font(name="Arial", size=10, bold=True)
        c_res.alignment = align("center", "center")
        c_res.border = thin_border()

        c_marge = style_formule(ws, i, 6, f"=C{i}-E15")
        c_marge.number_format = '0.00" kg"'

    # Mise en forme conditionnelle dashboard
    green_fill = PatternFill(start_color="C8E6C9", end_color="C8E6C9", fill_type="solid")
    red_fill   = PatternFill(start_color="FFCDD2", end_color="FFCDD2", fill_type="solid")
    ws.conditional_formatting.add("E26:E29",
        CellIsRule(operator="lessThanOrEqual", formula=["C26"], fill=green_fill))
    ws.conditional_formatting.add("E26:E29",
        CellIsRule(operator="greaterThan",     formula=["C26"], fill=red_fill))

    # ── Systèmes en place
    ws.row_dimensions[33].height = 8
    style_titre_section(ws, 34, 2, "  SYSTÈMES EN PLACE", 6)

    sys_champs = [
        ("Chauffage",       f"='DONNÉES PROJET'!C26"),
        ("Refroidissement", f"='DONNÉES PROJET'!C27"),
        ("Ventilation",     f"='DONNÉES PROJET'!C28"),
        ("ECS",             f"='DONNÉES PROJET'!C29"),
        ("ENR",             f"='DONNÉES PROJET'!C34"),
        ("Isolation murs",  f"='DONNÉES PROJET'!C42"),
        ("Isolation toiture",f"='DONNÉES PROJET'!C43"),
    ]
    for i, (label, formule) in enumerate(sys_champs, start=35):
        ws.row_dimensions[i].height = 20
        style_label(ws, i, 2, label)
        c = style_formule(ws, i, 3, formule)
        c.font = Font(name="Arial", size=10, color="008000")

        # Colonne ajustée
        c_adj = style_input(ws, i, 5, f"=C{i}")

    # ── Commentaires / notes IA
    ws.row_dimensions[44].height = 8
    style_titre_section(ws, 45, 2, "  COMMENTAIRES & RECOMMANDATIONS IA", 6)
    ws.row_dimensions[46].height = 80
    ws.merge_cells("B46:G46")
    c = ws["B46"]
    c.value = "← Zone remplie par l'analyse IA — modifiable manuellement"
    c.font = Font(name="Arial", size=10, color=C["texte_sec"], italic=True)
    c.fill = fill(C["vert_pale"])
    c.alignment = align("left", "top", wrap=True)
    c.border = thin_border(C["vert_clair"])

    ws.freeze_panes = "B3"


# ─────────────────────────────────────────────
#  FEUILLE 6 — BASES DONNÉES
# ─────────────────────────────────────────────

def creer_bases_donnees(ws):
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 30
    ws.column_dimensions["C"].width = 18
    ws.column_dimensions["D"].width = 18
    ws.column_dimensions["E"].width = 22
    ws.column_dimensions["F"].width = 18

    ws.merge_cells("B1:F1")
    c = ws["B1"]
    c.value = "BASES DE DONNÉES — RÉFÉRENTIEL ADEME / INIES / OTEIS"
    c.font = Font(name="Arial", bold=True, size=14, color=C["blanc"])
    c.fill = fill(C["vert_fonce"])
    c.alignment = align("center", "center")
    ws.row_dimensions[1].height = 35

    ws.merge_cells("B2:F2")
    c = ws["B2"]
    c.value = "Feuille en lecture seule — ne pas modifier les valeurs de référence"
    c.font = Font(name="Arial", size=9, color=C["rouge_erreur"], italic=True, bold=True)
    c.fill = fill(C["vert_moyen"])
    c.alignment = align("center", "center")
    ws.row_dimensions[2].height = 18

    def entete_table(row, cols_titres):
        for col, txt in cols_titres:
            style_entete_col(ws, row, col, txt)
        ws.row_dimensions[row].height = 20

    def ligne_donnee(row, valeurs, alt=False):
        bg = C["gris_ligne"] if alt else C["blanc"]
        for col, val in valeurs:
            c = ws.cell(row=row, column=col, value=val)
            c.font = Font(name="Arial", size=9)
            c.fill = fill(bg)
            c.alignment = align("left" if col == 2 else "center", "center")
            c.border = bottom_border()
        ws.row_dimensions[row].height = 18

    # ── Table 1 : Énergie
    ws.row_dimensions[4].height = 8
    style_titre_section(ws, 5, 2, "  FACTEURS D'ÉMISSION ÉNERGIE (ADEME Base Carbone 2023)", 5)
    entete_table(6, [(2,"Énergie"),(3,"kgCO2eq/kWh"),(4,"Unité"),(5,"Source"),(6,"Mise à jour")])

    energie_data = [
        ("Électricité France (mix)",  "0.0485",  "kgCO2/kWh_ef", "ADEME BC",  "2023"),
        ("Gaz naturel",               "0.2270",  "kgCO2/kWh_PCI","ADEME BC",  "2023"),
        ("Fioul domestique",          "0.3240",  "kgCO2/kWh_PCI","ADEME BC",  "2023"),
        ("Bois granulé (pellets)",    "0.0300",  "kgCO2/kWh_PCI","ADEME BC",  "2023"),
        ("Réseau de chaleur (moy.)",  "0.1100",  "kgCO2/kWh_ef", "ADEME BC",  "2023"),
        ("Réseau de chaleur (vert)",  "0.0600",  "kgCO2/kWh_ef", "ADEME BC",  "2023"),
    ]
    for i, row_data in enumerate(energie_data, start=7):
        ligne_donnee(i, [(2,row_data[0]),(3,row_data[1]),(4,row_data[2]),(5,row_data[3]),(6,row_data[4])], alt=(i%2==0))

    # ── Table 2 : Matériaux isolation
    ws.row_dimensions[15].height = 8
    style_titre_section(ws, 16, 2, "  MATÉRIAUX D'ISOLATION (INIES 2023)", 5)
    entete_table(17, [(2,"Matériau"),(3,"kgCO2eq/kg"),(4,"Densité (kg/m³)"),(5,"Bilan carbone"),(6,"Source")])

    isolation_data = [
        ("Laine de roche",     "1.28",  "50",  "Émetteur",  "INIES"),
        ("Laine de verre",     "1.35",  "15",  "Émetteur",  "INIES"),
        ("Polystyrène (EPS)",  "3.20",  "25",  "Émetteur",  "INIES"),
        ("Polyuréthane (PU)",  "3.80",  "35",  "Émetteur",  "INIES"),
        ("Ouate de cellulose", "0.45",  "45",  "Faible",    "INIES"),
        ("Liège expansé",      "-0.20", "120", "Stockage",  "INIES"),
        ("Chanvre",            "-0.30", "40",  "Stockage",  "INIES"),
        ("Laine de bois",      "-0.40", "50",  "Stockage",  "INIES"),
        ("Paille",             "-1.50", "80",  "Stockage",  "INIES"),
    ]
    for i, row_data in enumerate(isolation_data, start=18):
        bilan = row_data[3]
        ligne_donnee(i, [(2,row_data[0]),(3,row_data[1]),(4,row_data[2]),(5,bilan),(6,row_data[4])], alt=(i%2==0))
        if "Stockage" in bilan:
            ws.cell(row=i, column=5).font = Font(name="Arial", size=9, color="2E7D32", bold=True)

    # ── Table 3 : Systèmes CVC
    ws.row_dimensions[29].height = 8
    style_titre_section(ws, 30, 2, "  SYSTÈMES CVC — IMPACT FABRICATION (INIES 2023)", 5)
    entete_table(31, [(2,"Système"),(3,"Fabrication (kgCO2/m²/an)"),(4,"Conso. kWh_ep/m².an"),(5,"COP / EER"),(6,"Source")])

    cvc_data = [
        ("PAC air/eau",               "2.10", "45", "3.2 / 3.0", "INIES"),
        ("PAC réversible",            "1.80", "40", "3.5 / 3.2", "INIES"),
        ("PAC thermodynamique (ECS)", "1.50", "30", "2.8 / —",   "INIES"),
        ("PAC géothermique",          "2.80", "25", "4.5 / 4.0", "INIES"),
        ("Chaudière gaz cond.",       "0.90", "85", "0.98 / —",  "INIES"),
        ("Chaudière biomasse",        "1.20", "55", "0.88 / —",  "INIES"),
        ("Réseau de chaleur urbain",  "0.50", "60", "— / —",     "ADEME"),
        ("Double flux VMC",           "0.80", "8",  "—",         "INIES"),
        ("Simple flux VMC",           "0.40", "15", "—",         "INIES"),
        ("VRV / VRF",                 "2.40", "50", "3.8 / 3.5", "INIES"),
    ]
    for i, row_data in enumerate(cvc_data, start=32):
        ligne_donnee(i, [(2,row_data[0]),(3,row_data[1]),(4,row_data[2]),(5,row_data[3]),(6,row_data[4])], alt=(i%2==0))

    # ── Table 4 : Seuils RE2020
    ws.row_dimensions[44].height = 8
    style_titre_section(ws, 45, 2, "  SEUILS RE2020 — Ic_énergie (kgCO2eq/m².an)", 5)
    entete_table(46, [(2,"Type bâtiment"),(3,"2022"),(4,"2025"),(5,"2028"),(6,"2031")])

    re2020_data = [
        ("Bureaux",    "6.0", "5.0", "4.0", "3.0"),
        ("Logement",   "14.0","13.0","11.0","9.0"),
        ("Scolaire",   "8.0", "6.5", "5.5", "4.5"),
        ("Commerce",   "9.0", "7.5", "6.0", "5.0"),
        ("EHPAD",      "10.0","8.5", "7.0", "5.5"),
        ("Autres",     "10.0","8.5", "7.0", "5.5"),
    ]
    for i, row_data in enumerate(re2020_data, start=47):
        ligne_donnee(i, [(2,row_data[0]),(3,row_data[1]),(4,row_data[2]),(5,row_data[3]),(6,row_data[4])], alt=(i%2==0))

    ws.protection.sheet = True  # protège la feuille en lecture seule


# ─────────────────────────────────────────────
#  ASSEMBLAGE FINAL
# ─────────────────────────────────────────────

def generer_template(chemin_sortie: str):
    wb = Workbook()

    # Renommer et créer les feuilles
    ws1 = wb.active
    ws1.title = "ACCUEIL"

    ws2 = wb.create_sheet("DONNÉES PROJET")
    ws3 = wb.create_sheet("CALCUL CARBONE")
    ws4 = wb.create_sheet("VARIANTES")
    ws5 = wb.create_sheet("DASHBOARD")
    ws6 = wb.create_sheet("BASES DONNÉES")

    # Remplir chaque feuille
    print("  → ACCUEIL...")
    creer_accueil(ws1)

    print("  → DONNÉES PROJET...")
    creer_donnees_projet(ws2)

    print("  → CALCUL CARBONE...")
    creer_calcul_carbone(ws3)

    print("  → VARIANTES...")
    creer_variantes(ws4)

    print("  → DASHBOARD...")
    creer_dashboard(ws5)

    print("  → BASES DONNÉES...")
    creer_bases_donnees(ws6)

    # Onglet actif = DONNÉES PROJET à l'ouverture
    wb.active = ws2

    # Onglets colorés
    ws1.sheet_properties.tabColor = "1B4332"
    ws2.sheet_properties.tabColor = "52B788"
    ws3.sheet_properties.tabColor = "2D6A4F"
    ws4.sheet_properties.tabColor = "74C69D"
    ws5.sheet_properties.tabColor = "B7E4C7"
    ws6.sheet_properties.tabColor = "95D5B2"

    wb.save(chemin_sortie)
    print(f"\n✓ Template généré : {chemin_sortie}")
    return chemin_sortie


if __name__ == "__main__":
    import sys
    sortie = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/outil-carbone/data/template_calcul.xlsx"
    print(f"\nGénération du template Excel OTEIS Bas Carbone...")
    generer_template(sortie)
