"""
ChatIA — Gestionnaire de conversation IA avec contexte projet.

Fonctionnalités :
  - Injection automatique du contexte projet dans le system prompt
  - Historique de conversation multi-tours
  - Détection d'intentions (calcul, comparaison, export…)
  - Mise à jour du dashboard depuis le chat ("Modifie le système de chauffage")
  - Streaming des réponses (optionnel)
  - Sauvegarde de la session
"""

import json
import re
from pathlib import Path
from datetime import datetime
from typing import Any, Optional, Generator
import anthropic


# ─────────────────────────────────────────────
#  Prompts système
# ─────────────────────────────────────────────

SYSTEM_BASE = """Tu es un ingénieur expert en bilan carbone et conception thermique du bâtiment chez OTEIS, un bureau d'études techniques spécialisé en génie climatique.

Tu analyses des projets de construction en phase APS/APD selon la méthode RE2020.
Tes bases de données : ADEME Base Carbone, INIES, OTEIS retours d'expérience.

RÈGLES DE RÉPONSE :
- Réponds en français, de façon directe et technique
- Utilise toujours des chiffres concrets avec leurs unités (kgCO2eq/m².an, kWh_ep/m².an)
- Sois concis : 3-5 phrases sauf si l'utilisateur demande un développement
- Si tu modifies une valeur du dashboard, annonce-le clairement avec le format : ACTION:UPDATE:{champ}:{valeur}
- Si tu genères un rapport, utilise le format : ACTION:EXPORT:{format}
- Quand tu compares des variantes, structure ta réponse avec les indicateurs clés
- Cite toujours tes sources (INIES, ADEME, RE2020)

CONTEXTE PROJET :
{contexte_projet}

BILAN CALCULÉ :
{bilan}

CONFORMITÉ RE2020 :
{re2020}

MODIFICATIONS MANUELLES EN COURS :
{modifications}
"""

INTENT_DETECTOR_PROMPT = """Analyse ce message utilisateur et retourne UNIQUEMENT un JSON avec :
- "intention" : parmi ["question_technique", "modification_dashboard", "comparaison_variantes", "export", "explication_re2020", "calcul_specifique", "autre"]
- "champs_concernes" : liste des champs du dashboard potentiellement concernés
- "action" : action à exécuter si applicable

Message : "{message}"

Réponds UNIQUEMENT avec le JSON, sans explication."""


# ─────────────────────────────────────────────
#  Classe principale
# ─────────────────────────────────────────────

class ChatIA:
    """
    Gestionnaire de conversation IA avec contexte projet complet.
    """

    def __init__(self, api_key: Optional[str] = None):
        """
        Initialise le client Anthropic.

        Args:
            api_key: clé API Anthropic. Si None, lit ANTHROPIC_API_KEY.
        """
        self.client = anthropic.Anthropic(api_key=api_key) if api_key else anthropic.Anthropic()
        self.historique: list[dict] = []
        self.etat_projet: dict = {}
        self.etat_dashboard: dict = {}
        self._session_id = datetime.now().strftime("%Y%m%d_%H%M%S")

    # ─────────────────────────────────────────
    #  Interface principale
    # ─────────────────────────────────────────

    def charger_contexte(self, projet: dict, bilan: dict, dashboard: dict):
        """Charge le contexte du projet dans le gestionnaire."""
        self.etat_projet   = projet
        self.etat_bilan    = bilan
        self.etat_dashboard = dashboard

    def envoyer(self, message: str, streaming: bool = False) -> dict:
        """
        Envoie un message et retourne la réponse.

        Returns:
            {
              "contenu": str,
              "actions": list[dict],   // actions détectées (UPDATE, EXPORT…)
              "intention": str,
              "tokens_utilises": int
            }
        """
        # Détecter l'intention
        intention = self._detecter_intention(message)

        # Construire le system prompt avec contexte
        system = self._construire_system_prompt()

        # Ajouter au historique
        self.historique.append({"role": "user", "content": message})

        # Appel API
        if streaming:
            return self._envoyer_streaming(system)
        else:
            return self._envoyer_normal(system, intention)

    def envoyer_streaming(self, message: str) -> Generator[str, None, None]:
        """
        Envoie un message en mode streaming.
        Yields des chunks de texte au fur et à mesure.
        """
        system = self._construire_system_prompt()
        self.historique.append({"role": "user", content: message})

        with self.client.messages.stream(
            model="claude-sonnet-4-20250514",
            max_tokens=2000,
            system=system,
            messages=self.historique
        ) as stream:
            full_text = ""
            for chunk in stream.text_stream:
                full_text += chunk
                yield chunk

            # Enregistrer la réponse complète
            self.historique.append({"role": "assistant", "content": full_text})
            self._sauvegarder_session()

    def reset_historique(self):
        """Efface l'historique de conversation (garde le contexte projet)."""
        self.historique = []

    def get_suggestions(self) -> list[str]:
        """Retourne des suggestions de questions pertinentes selon le contexte."""
        b = self.etat_bilan
        p = self.etat_projet

        suggestions = [
            f"Quel est le point faible de ce projet vis-à-vis de la RE2020 ?",
            f"Compare PAC air/eau vs chaudière biomasse pour ce projet",
            f"Quelles ENR permettraient d'atteindre le seuil RE2020 2025 ?",
            f"Explique le calcul de l'Ic_énergie pour ce type de bâtiment",
            f"Quelles améliorations d'isolation recommandes-tu ?",
        ]

        # Suggestions contextuelles
        if b.get("ic_energie", 0) > 5:
            suggestions.insert(0, f"L'Ic_énergie est à {b.get('ic_energie')} kgCO2/m².an, comment l'améliorer ?")

        type_bat = p.get("type_batiment", "")
        if type_bat:
            suggestions.append(f"Quels sont les enjeux RE2020 spécifiques aux {type_bat} ?")

        return suggestions[:5]

    # ─────────────────────────────────────────
    #  Méthodes internes
    # ─────────────────────────────────────────

    def _envoyer_normal(self, system: str, intention: dict) -> dict:
        """Envoi synchrone standard."""
        response = self.client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2000,
            system=system,
            messages=self.historique
        )

        contenu = response.content[0].text
        self.historique.append({"role": "assistant", "content": contenu})

        # Détecter les actions dans la réponse
        actions = self._extraire_actions(contenu)

        self._sauvegarder_session()

        return {
            "contenu": self._nettoyer_actions(contenu),
            "contenu_brut": contenu,
            "actions": actions,
            "intention": intention.get("intention", "autre"),
            "tokens_utilises": response.usage.input_tokens + response.usage.output_tokens,
            "suggestions_suivantes": self.get_suggestions()
        }

    def _detecter_intention(self, message: str) -> dict:
        """Détecte l'intention du message utilisateur."""
        msg_lower = message.lower()

        # Détection simple par mots-clés (sans appel API supplémentaire)
        if any(w in msg_lower for w in ["modifie", "change", "met à jour", "remplace", "ajuste"]):
            return {"intention": "modification_dashboard", "champs_concernes": [], "action": "update"}

        if any(w in msg_lower for w in ["compare", "variante", "vs", "versus", "entre"]):
            return {"intention": "comparaison_variantes", "champs_concernes": [], "action": "compare"}

        if any(w in msg_lower for w in ["exporte", "export", "rapport", "pdf", "excel"]):
            return {"intention": "export", "champs_concernes": [], "action": "export"}

        if any(w in msg_lower for w in ["re2020", "seuil", "conforme", "conformité"]):
            return {"intention": "explication_re2020", "champs_concernes": [], "action": None}

        if any(w in msg_lower for w in ["calcule", "calcul", "bilan", "ic_energie", "kgco2"]):
            return {"intention": "calcul_specifique", "champs_concernes": [], "action": None}

        return {"intention": "question_technique", "champs_concernes": [], "action": None}

    def _construire_system_prompt(self) -> str:
        """Construit le system prompt avec le contexte projet complet."""
        p = self.etat_projet
        b = self.etat_bilan
        d = self.etat_dashboard

        # Contexte projet
        ctx_projet = f"""- Nom : {p.get('nom_projet', '—')}
- Type : {p.get('type_batiment', '—')} | Localisation : {p.get('localisation', '—')}
- Surface : {p.get('surface_plancher', 0)} m² | {p.get('nb_niveaux', '—')} niveaux
- Zone climatique : {p.get('zone_climatique', 'H1')} | Livraison : {p.get('annee_livraison', '—')}
- Chauffage : {p.get('systeme_cvc', {}).get('chauffage', '—')}
- Ventilation : {p.get('systeme_cvc', {}).get('ventilation', '—')}
- ECS : {p.get('systeme_cvc', {}).get('ecs', '—')}
- ENR : {', '.join(p.get('enr', [])) or 'Aucune'}
- Isolation murs : {p.get('isolation', {}).get('murs', {}).get('materiau', '—')} {p.get('isolation', {}).get('murs', {}).get('epaisseur_cm', '—')} cm
- Isolation toiture : {p.get('isolation', {}).get('toiture', {}).get('materiau', '—')} {p.get('isolation', {}).get('toiture', {}).get('epaisseur_cm', '—')} cm
- Menuiseries : Uw={p.get('menuiseries', {}).get('uw', '—')} W/m²K | Surface vitrée : {p.get('surface_vitre_pct', '—')}%"""

        # Bilan
        ctx_bilan = f"""- Ic_énergie  : {b.get('ic_energie', 0)} kgCO2eq/m².an
- Ic_bâtiment : {b.get('ic_batiment', 0)} kgCO2eq/m².an
- Ic_total    : {b.get('ic_total', 0)} kgCO2eq/m².an
- Cep         : {b.get('cep', 0)} kWh_ep/m².an
- Bbio estimé : {b.get('bbio', 0)} pts"""

        # RE2020
        re2020 = b.get("conformite_re2020", {}).get("niveaux", {})
        ctx_re2020 = "\n".join([
            f"  - Seuil {an} ({v.get('seuil_kgco2_m2_an', v.get('seuil', '?'))} kgCO2) : "
            f"{'CONFORME' if v.get('conforme') else 'NON CONFORME'} "
            f"(marge : {v.get('marge', '?')} kgCO2)"
            for an, v in re2020.items()
        ]) if re2020 else "Non calculé"

        # Modifications manuelles
        manuelles = [
            (k, v) for k, v in d.items()
            if isinstance(v, dict) and v.get("modifie_manuellement")
        ]
        ctx_modifs = "\n".join([
            f"  - {k} : {v.get('valeur')} (était {v.get('historique', [{}])[-1].get('valeur_precedente', '?')})"
            for k, v in manuelles
        ]) if manuelles else "  Aucune modification manuelle"

        return SYSTEM_BASE.format(
            contexte_projet=ctx_projet,
            bilan=ctx_bilan,
            re2020=ctx_re2020,
            modifications=ctx_modifs
        )

    def _extraire_actions(self, contenu: str) -> list[dict]:
        """Extrait les actions encodées dans la réponse IA."""
        actions = []
        pattern = r"ACTION:(\w+):([^:\n]+):([^\n]+)"

        for match in re.finditer(pattern, contenu):
            action_type, cible, valeur = match.groups()
            actions.append({
                "type": action_type,
                "cible": cible.strip(),
                "valeur": valeur.strip(),
                "raw": match.group(0)
            })

        return actions

    def _nettoyer_actions(self, contenu: str) -> str:
        """Retire les balises ACTION: du texte visible."""
        return re.sub(r"\s*ACTION:\w+:[^:\n]+:[^\n]+", "", contenu).strip()

    def _sauvegarder_session(self):
        """Sauvegarde la session de chat pour la traçabilité."""
        sessions_dir = Path(__file__).parent.parent / "data" / "sessions_chat"
        sessions_dir.mkdir(exist_ok=True)

        session_file = sessions_dir / f"session_{self._session_id}.json"
        with open(session_file, "w", encoding="utf-8") as f:
            json.dump({
                "session_id": self._session_id,
                "projet": self.etat_projet.get("nom_projet", "—"),
                "nb_messages": len(self.historique),
                "historique": self.historique,
                "derniere_mise_a_jour": datetime.now().isoformat()
            }, f, ensure_ascii=False, indent=2)


# ─────────────────────────────────────────────
#  Gestionnaire de sessions multiples
# ─────────────────────────────────────────────

class GestionnaireSessions:
    """Gère plusieurs sessions de chat (utile pour des projets multiples)."""

    def __init__(self):
        self._sessions: dict[str, ChatIA] = {}

    def creer_session(self, projet_id: str, api_key: str = None) -> ChatIA:
        chat = ChatIA(api_key=api_key)
        self._sessions[projet_id] = chat
        return chat

    def get_session(self, projet_id: str) -> Optional[ChatIA]:
        return self._sessions.get(projet_id)

    def supprimer_session(self, projet_id: str):
        self._sessions.pop(projet_id, None)


# ─────────────────────────────────────────────
#  Prompts spécialisés
# ─────────────────────────────────────────────

class PromptsSpecialises:
    """Prompts prêts à l'emploi pour les cas d'usage fréquents."""

    @staticmethod
    def analyser_conformite(ic_energie: float, type_bat: str) -> str:
        return (
            f"Le projet de type '{type_bat}' a un Ic_énergie de {ic_energie} kgCO2eq/m².an. "
            f"Analyse la conformité RE2020 en détail et donne 3 leviers d'amélioration concrets "
            f"classés par efficacité carbone décroissante. Inclus les ordres de grandeur des gains."
        )

    @staticmethod
    def comparer_systemes(sys_a: str, sys_b: str, surface: float, zone: str) -> str:
        return (
            f"Compare les systèmes '{sys_a}' et '{sys_b}' pour un bâtiment de {surface} m² "
            f"en zone {zone}. Donne : Ic_énergie estimé pour chacun (kgCO2/m².an), "
            f"consommation Ep (kWh_ep/m².an), avantages/inconvénients RE2020, "
            f"et ta recommandation finale avec justification chiffrée."
        )

    @staticmethod
    def optimiser_enveloppe(ic_actuel: float, surface: float, type_bat: str) -> str:
        return (
            f"Pour un {type_bat} de {surface} m² avec Ic_énergie à {ic_actuel} kgCO2/m².an, "
            f"propose 3 niveaux d'amélioration de l'enveloppe (isolation + menuiseries) "
            f"avec pour chacun : investissement estimé (€/m²), gain Ic_énergie attendu, "
            f"impact sur le niveau RE2020 atteint."
        )

    @staticmethod
    def generer_note_cadrage(projet: dict) -> str:
        p = projet
        return (
            f"Génère une note de cadrage APS pour le projet '{p.get('nom_projet')}' "
            f"({p.get('type_batiment')}, {p.get('surface_plancher')} m², {p.get('localisation')}). "
            f"La note doit inclure : contexte réglementaire RE2020, enjeux carbone du projet, "
            f"orientations techniques recommandées pour les systèmes CVC et l'enveloppe, "
            f"et objectifs chiffrés en kgCO2eq/m².an. Format : paragraphes structurés, environ 300 mots."
        )

    @staticmethod
    def analyser_variantes(variantes: list[dict]) -> str:
        desc = "\n".join([
            f"- {v.get('nom', f'Variante {i+1}')} : "
            f"chauffage={v.get('systeme_cvc', {}).get('chauffage', '?')}, "
            f"ENR={', '.join(v.get('enr', [])) or 'aucune'}, "
            f"Ic_énergie estimé={v.get('ic_energie', '?')} kgCO2/m².an"
            for i, v in enumerate(variantes)
        ])
        return (
            f"Analyse ces {len(variantes)} variantes techniques :\n{desc}\n\n"
            f"Pour chacune : conformité RE2020 (seuils 2022/2025/2028), "
            f"point fort et faible, estimation surcoût investissement. "
            f"Conclure avec une recommandation claire et motivée."
        )
