"""
Exporteur — génère les rapports de sortie depuis l'état du dashboard.

Formats :
  - Excel  : classeur enrichi avec bilan + graphiques (openpyxl)
  - PDF    : rapport APS/APD mis en page (reportlab)
  - PowerBI: JSON structuré pour intégration Power BI Desktop
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Any


# ─────────────────────────────────────────────
#  Exporteur principal
# ─────────────────────────────────────────────

class Exporteur:

    def __init__(self, dossier_sortie: Path = None):
        self.dossier_sortie = dossier_sortie or Path(__file__).parent.parent / "data" / "exports"
        self.dossier_sortie.mkdir(parents=True, exist_ok=True)

    def exporter(self, etat: dict, format: str = "excel", nom: str = "projet") -> Path:
        slug = nom.replace(" ", "_").replace("/", "-")[:40]
        ts   = datetime.now().strftime("%Y%m%d_%H%M")

        if format == "excel":
            return self._export_excel(etat, slug, ts)
        elif format == "pdf":
            return self._export_pdf(etat, slug, ts)
        elif format == "powerbi":
            return self._export_powerbi(etat, slug, ts)
        else:
            raise ValueError(f"Format inconnu : {format}")

    # ─────────────────────────────────────────
    #  Export Excel
    # ─────────────────────────────────────────

    def _export_excel(self, etat: dict, slug: str, ts: str) -> Path:
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
            from openpyxl.utils import get_column_letter
        except ImportError:
            return self._export_json_fallback(etat, slug, ts, "excel")

        wb = openpyxl.Workbook()

        # ── Feuille Rapport
        ws = wb.active
        ws.title = "Rapport Bilan Carbone"
        self._excel_rapport(ws, etat, openpyxl)

        # ── Feuille Données brutes
        ws2 = wb.create_sheet("Données brutes")
        self._excel_donnees_brutes(ws2, etat)

        # ── Feuille Modifications
        ws3 = wb.create_sheet("Traçabilité modifications")
        self._excel_tracabilite(ws3, etat)

        chemin = self.dossier_sortie / f"rapport_{slug}_{ts}.xlsx"
        wb.save(chemin)
        return chemin

    def _excel_rapport(self, ws, etat: dict, openpyxl):
        from openpyxl.styles import Font, PatternFill, Alignment

        def fill(c): return PatternFill("solid", fgColor=c)
        def font(bold=False, size=11, color="000000"): return Font(name="Arial", bold=bold, size=size, color=color)
        def align(h="left", v="center"): return Alignment(horizontal=h, vertical=v)

        ws.column_dimensions["A"].width = 3
        ws.column_dimensions["B"].width = 36
        ws.column_dimensions["C"].width = 22
        ws.column_dimensions["D"].width = 16
        ws.column_dimensions["E"].width = 20

        # En-tête
        ws.merge_cells("B1:E1")
        c = ws["B1"]
        c.value = "RAPPORT BILAN CARBONE — APS/APD"
        c.font = Font(name="Arial", bold=True, size=16, color="FFFFFF")
        c.fill = fill("1B4332")
        c.alignment = align("center")
        ws.row_dimensions[1].height = 40

        projet = etat.get("projet", etat)
        bilan  = etat.get("bilan", {})
        dashboard = etat.get("dashboard", {})

        # Infos projet
        ws.merge_cells("B3:E3")
        ws["B3"].value = f"Projet : {projet.get('nom_projet', '—')}"
        ws["B3"].font = Font(name="Arial", bold=True, size=13, color="1B4332")
        ws.row_dimensions[3].height = 28

        infos = [
            ("Maître d'ouvrage", projet.get("maitre_ouvrage", "")),
            ("Localisation",     projet.get("localisation", "")),
            ("Type de bâtiment", projet.get("type_batiment", "")),
            ("Surface (m²)",     projet.get("surface_plancher", 0)),
            ("Zone climatique",  projet.get("zone_climatique", "")),
            ("Date du rapport",  datetime.now().strftime("%d/%m/%Y %H:%M")),
        ]
        for i, (label, val) in enumerate(infos, start=4):
            ws.row_dimensions[i].height = 18
            ws.cell(row=i, column=2, value=label).font = Font(name="Arial", size=10, color="546E7A")
            ws.cell(row=i, column=3, value=val).font = Font(name="Arial", size=10, bold=True)

        # Indicateurs carbone
        row = 12
        ws.merge_cells(f"B{row}:E{row}")
        ws.cell(row=row, column=2, value="INDICATEURS CARBONE & ÉNERGIE").font = Font(
            name="Arial", bold=True, size=11, color="FFFFFF")
        ws.cell(row=row, column=2).fill = fill("2D6A4F")
        ws.row_dimensions[row].height = 24

        kpis = [
            ("Ic_énergie",             bilan.get("ic_energie", 0),    "kgCO2eq/m².an"),
            ("Ic_bâtiment",            bilan.get("ic_batiment", 0),   "kgCO2eq/m².an"),
            ("Ic_total",               bilan.get("ic_total", 0),      "kgCO2eq/m².an"),
            ("Consommation Ep (Cep)",  bilan.get("cep", 0),           "kWh_ep/m².an"),
            ("Bbio estimé",            bilan.get("bbio", 0),          "pts"),
            ("Ic total projet",        round(bilan.get("ic_total", 0) * projet.get("surface_plancher", 0) / 1000, 1), "tCO2"),
        ]
        for i, (label, val, unite) in enumerate(kpis, start=row+1):
            ws.row_dimensions[i].height = 20
            ws.cell(row=i, column=2, value=label).font = Font(name="Arial", size=10, color="546E7A")
            c_val = ws.cell(row=i, column=3, value=val)
            c_val.font = Font(name="Arial", bold=True, size=10, color="1B4332")
            c_val.number_format = "0.00"
            ws.cell(row=i, column=4, value=unite).font = Font(name="Arial", size=9, color="9E9E9E")

        # RE2020
        row = row + len(kpis) + 2
        ws.merge_cells(f"B{row}:E{row}")
        ws.cell(row=row, column=2, value="CONFORMITÉ RE2020").font = Font(
            name="Arial", bold=True, size=11, color="FFFFFF")
        ws.cell(row=row, column=2).fill = fill("2D6A4F")

        re2020 = bilan.get("conformite_re2020", {}).get("niveaux", {})
        for i, (annee, v) in enumerate(re2020.items(), start=row+1):
            ws.row_dimensions[i].height = 20
            ws.cell(row=i, column=2, value=f"Seuil RE2020 — {annee}").font = Font(name="Arial", size=10)
            ws.cell(row=i, column=3, value=v.get("seuil_kgco2_m2_an", v.get("seuil", "?"))).number_format = "0.00"
            statut = "CONFORME" if v.get("conforme") else "NON CONFORME"
            c_st = ws.cell(row=i, column=4, value=statut)
            c_st.font = Font(name="Arial", bold=True, size=10,
                color="2E7D32" if v.get("conforme") else "C62828")
            c_st.fill = fill("E8F5E9" if v.get("conforme") else "FFEBEE")

        # Modifications manuelles
        row += len(re2020) + 2
        manuelles = []
        if isinstance(dashboard, dict):
            manuelles = [(k, v) for k, v in dashboard.items()
                        if isinstance(v, dict) and v.get("modifie_manuellement")]

        if manuelles:
            ws.merge_cells(f"B{row}:E{row}")
            ws.cell(row=row, column=2, value="MODIFICATIONS MANUELLES").font = Font(
                name="Arial", bold=True, size=11, color="FFFFFF")
            ws.cell(row=row, column=2).fill = fill("F57F17")
            for i, (k, v) in enumerate(manuelles, start=row+1):
                ws.row_dimensions[i].height = 18
                ws.cell(row=i, column=2, value=k).font = Font(name="Arial", size=10, color="E65100")
                ws.cell(row=i, column=3, value=str(v.get("valeur"))).font = Font(name="Arial", size=10, bold=True)
                hist = v.get("historique", [{}])
                if hist:
                    ws.cell(row=i, column=4, value=f"était : {hist[-1].get('valeur_precedente', '?')}").font = Font(
                        name="Arial", size=9, color="9E9E9E")

    def _excel_donnees_brutes(self, ws, etat: dict):
        ws.cell(row=1, column=1, value="Clé")
        ws.cell(row=1, column=2, value="Valeur")
        ws.cell(row=1, column=3, value="Modifié manuellement")
        ws.cell(row=1, column=4, value="Source")

        dash = etat.get("dashboard", {})
        if isinstance(dash, dict):
            for i, (k, v) in enumerate(dash.items(), start=2):
                if isinstance(v, dict):
                    ws.cell(row=i, column=1, value=k)
                    ws.cell(row=i, column=2, value=str(v.get("valeur", "")))
                    ws.cell(row=i, column=3, value="Oui" if v.get("modifie_manuellement") else "Non")
                    ws.cell(row=i, column=4, value=v.get("source", ""))

    def _excel_tracabilite(self, ws, etat: dict):
        ws.cell(row=1, column=1, value="Champ")
        ws.cell(row=1, column=2, value="Valeur actuelle")
        ws.cell(row=1, column=3, value="Valeur précédente")
        ws.cell(row=1, column=4, value="Source")
        ws.cell(row=1, column=5, value="Timestamp")

        dash = etat.get("dashboard", {})
        row = 2
        if isinstance(dash, dict):
            for k, v in dash.items():
                if isinstance(v, dict) and v.get("historique"):
                    for h in v.get("historique", []):
                        ws.cell(row=row, column=1, value=k)
                        ws.cell(row=row, column=2, value=str(v.get("valeur")))
                        ws.cell(row=row, column=3, value=str(h.get("valeur_precedente", "")))
                        ws.cell(row=row, column=4, value=h.get("source", ""))
                        ws.cell(row=row, column=5, value=h.get("timestamp", ""))
                        row += 1

    # ─────────────────────────────────────────
    #  Export PDF
    # ─────────────────────────────────────────

    def _export_pdf(self, etat: dict, slug: str, ts: str) -> Path:
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.lib import colors
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.units import cm, mm
            from reportlab.platypus import (
                SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                HRFlowable, PageBreak
            )
            from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
        except ImportError:
            return self._export_json_fallback(etat, slug, ts, "pdf")

        chemin = self.dossier_sortie / f"rapport_{slug}_{ts}.pdf"
        projet = etat.get("projet", etat)
        bilan  = etat.get("bilan", {})

        # Couleurs OTEIS
        VERT_FONCE  = colors.HexColor("#1B4332")
        VERT_MOYEN  = colors.HexColor("#2D6A4F")
        VERT_CLAIR  = colors.HexColor("#52B788")
        VERT_PALE   = colors.HexColor("#D8F3DC")
        GRIS_TEXTE  = colors.HexColor("#546E7A")
        ORANGE_MOD  = colors.HexColor("#F57F17")

        doc = SimpleDocTemplate(
            str(chemin), pagesize=A4,
            leftMargin=2*cm, rightMargin=2*cm,
            topMargin=2.5*cm, bottomMargin=2*cm,
            title=f"Rapport Bilan Carbone — {projet.get('nom_projet', '—')}",
            author="OTEIS Group — Outil Bas Carbone",
            subject="Bilan carbone APS/APD RE2020"
        )

        styles = getSampleStyleSheet()

        # Styles personnalisés
        s_titre = ParagraphStyle("titre", parent=styles["Title"],
            fontName="Helvetica-Bold", fontSize=22,
            textColor=VERT_FONCE, spaceAfter=6, leading=26)
        s_sous_titre = ParagraphStyle("sous_titre", parent=styles["Normal"],
            fontName="Helvetica", fontSize=11, textColor=VERT_MOYEN,
            spaceAfter=20, leading=14)
        s_h1 = ParagraphStyle("h1", parent=styles["Heading1"],
            fontName="Helvetica-Bold", fontSize=13, textColor=colors.white,
            backColor=VERT_FONCE, spaceAfter=0, spaceBefore=16,
            leftIndent=-10, rightIndent=-10, leading=18,
            borderPad=8)
        s_h2 = ParagraphStyle("h2", parent=styles["Heading2"],
            fontName="Helvetica-Bold", fontSize=11, textColor=VERT_FONCE,
            spaceBefore=12, spaceAfter=4)
        s_body = ParagraphStyle("body", parent=styles["Normal"],
            fontName="Helvetica", fontSize=10, textColor=GRIS_TEXTE,
            leading=14, spaceAfter=4)
        s_small = ParagraphStyle("small", parent=styles["Normal"],
            fontName="Helvetica", fontSize=8, textColor=GRIS_TEXTE,
            leading=11)
        s_val = ParagraphStyle("val", parent=styles["Normal"],
            fontName="Helvetica-Bold", fontSize=10, textColor=VERT_FONCE)

        story = []

        # ── PAGE 1 : En-tête + KPIs
        story.append(Paragraph("BILAN CARBONE — APS/APD", s_titre))
        story.append(Paragraph(
            f"Outil bas carbone OTEIS &nbsp;·&nbsp; {datetime.now().strftime('%d/%m/%Y')}",
            s_sous_titre))
        story.append(HRFlowable(width="100%", thickness=2, color=VERT_CLAIR, spaceAfter=16))

        # Tableau infos projet
        infos_data = [
            ["PROJET", projet.get("nom_projet", "—")],
            ["Maître d'ouvrage", projet.get("maitre_ouvrage", "—")],
            ["Localisation",     projet.get("localisation", "—")],
            ["Type de bâtiment", projet.get("type_batiment", "—")],
            ["Surface",          f"{projet.get('surface_plancher', 0)} m²"],
            ["Zone climatique",  projet.get("zone_climatique", "H1")],
            ["Année livraison",  str(projet.get("annee_livraison", "—"))],
        ]
        t_infos = Table(infos_data, colWidths=[5*cm, 12*cm])
        t_infos.setStyle(TableStyle([
            ("FONTNAME",    (0,0), (-1,-1), "Helvetica"),
            ("FONTSIZE",    (0,0), (-1,-1), 9),
            ("FONTNAME",    (0,0), (0,-1), "Helvetica-Bold"),
            ("TEXTCOLOR",   (0,0), (0,-1), GRIS_TEXTE),
            ("TEXTCOLOR",   (1,0), (1,-1), colors.black),
            ("FONTNAME",    (0,0), (1,0), "Helvetica-Bold"),
            ("FONTSIZE",    (0,0), (1,0), 11),
            ("TEXTCOLOR",   (0,0), (1,0), VERT_FONCE),
            ("BACKGROUND",  (0,0), (1,0), VERT_PALE),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#F5F5F5")]),
            ("GRID",        (0,0), (-1,-1), 0.5, colors.HexColor("#E0E0E0")),
            ("TOPPADDING",  (0,0), (-1,-1), 5),
            ("BOTTOMPADDING",(0,0),(-1,-1), 5),
            ("LEFTPADDING", (0,0), (-1,-1), 8),
        ]))
        story.append(t_infos)
        story.append(Spacer(1, 20))

        # ── Indicateurs carbone
        story.append(Paragraph("INDICATEURS CARBONE &amp; ÉNERGIE", s_h1))
        story.append(Spacer(1, 8))

        kpi_data = [
            ["Indicateur", "Valeur calculée", "Unité", "Source"],
            ["Ic énergie",   str(bilan.get("ic_energie", 0)),   "kgCO<sub>2</sub>eq/m².an", "ADEME / INIES"],
            ["Ic bâtiment",  str(bilan.get("ic_batiment", 0)),  "kgCO<sub>2</sub>eq/m².an", "INIES"],
            ["Ic total",     str(bilan.get("ic_total", 0)),      "kgCO<sub>2</sub>eq/m².an", "Calculé"],
            ["Cep",          str(bilan.get("cep", 0)),           "kWh_ep/m².an",             "RE2020"],
            ["Bbio estimé",  str(bilan.get("bbio", 0)),          "pts",                      "Estimé APS"],
        ]
        t_kpi = Table(kpi_data, colWidths=[5*cm, 4*cm, 5*cm, 3*cm])
        t_kpi.setStyle(TableStyle([
            ("BACKGROUND",  (0,0), (-1,0), VERT_FONCE),
            ("TEXTCOLOR",   (0,0), (-1,0), colors.white),
            ("FONTNAME",    (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE",    (0,0), (-1,-1), 9),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[VERT_PALE, colors.white]),
            ("GRID",        (0,0), (-1,-1), 0.5, VERT_CLAIR),
            ("ALIGN",       (1,0), (1,-1), "CENTER"),
            ("FONTNAME",    (0,1), (0,-1), "Helvetica-Bold"),
            ("TEXTCOLOR",   (0,1), (0,-1), VERT_FONCE),
            ("TOPPADDING",  (0,0), (-1,-1), 6),
            ("BOTTOMPADDING",(0,0),(-1,-1), 6),
            ("LEFTPADDING", (0,0), (-1,-1), 8),
        ]))
        story.append(t_kpi)
        story.append(Spacer(1, 20))

        # ── RE2020
        story.append(Paragraph("CONFORMITÉ RE2020 — Ic énergie", s_h1))
        story.append(Spacer(1, 8))

        re2020 = bilan.get("conformite_re2020", {}).get("niveaux", {})
        re_data = [["Seuil", "Limite (kgCO2eq/m².an)", "Ic projet", "Résultat", "Marge"]]
        for annee, v in re2020.items():
            seuil = v.get("seuil_kgco2_m2_an", v.get("seuil", "?"))
            conforme = v.get("conforme", False)
            marge = v.get("marge", "?")
            re_data.append([
                f"RE2020 — {annee}",
                str(seuil),
                str(bilan.get("ic_energie", 0)),
                "CONFORME" if conforme else "NON CONFORME",
                f"+{marge}" if isinstance(marge, (int, float)) and marge >= 0 else str(marge)
            ])

        t_re = Table(re_data, colWidths=[4*cm, 4.5*cm, 3*cm, 4*cm, 2*cm])
        style_re = [
            ("BACKGROUND",  (0,0), (-1,0), VERT_FONCE),
            ("TEXTCOLOR",   (0,0), (-1,0), colors.white),
            ("FONTNAME",    (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE",    (0,0), (-1,-1), 9),
            ("GRID",        (0,0), (-1,-1), 0.5, VERT_CLAIR),
            ("TOPPADDING",  (0,0), (-1,-1), 6),
            ("BOTTOMPADDING",(0,0),(-1,-1), 6),
            ("LEFTPADDING", (0,0), (-1,-1), 8),
            ("ALIGN",       (1,0), (-1,-1), "CENTER"),
        ]
        for i, (annee, v) in enumerate(re2020.items(), start=1):
            c = colors.HexColor("#E8F5E9") if v.get("conforme") else colors.HexColor("#FFEBEE")
            style_re.append(("BACKGROUND", (0, i), (-1, i), c))
            tc = colors.HexColor("#2E7D32") if v.get("conforme") else colors.HexColor("#C62828")
            style_re.append(("TEXTCOLOR", (3, i), (3, i), tc))
            style_re.append(("FONTNAME", (3, i), (3, i), "Helvetica-Bold"))
        t_re.setStyle(TableStyle(style_re))
        story.append(t_re)
        story.append(Spacer(1, 20))

        # ── Systèmes
        story.append(Paragraph("SYSTÈMES EN PLACE", s_h1))
        story.append(Spacer(1, 8))

        cvc = projet.get("systeme_cvc", {})
        sys_data = [
            ["Poste", "Système retenu", "Remarque"],
            ["Chauffage",      cvc.get("chauffage", "—"),    ""],
            ["Refroidissement", cvc.get("climatisation", cvc.get("refroidissement", "—")), ""],
            ["Ventilation",    cvc.get("ventilation", "—"),  ""],
            ["ECS",            cvc.get("ecs", "—"),          ""],
            ["ENR",            ", ".join(projet.get("enr", [])) or "Aucune", ""],
        ]
        t_sys = Table(sys_data, colWidths=[4*cm, 7*cm, 6*cm])
        t_sys.setStyle(TableStyle([
            ("BACKGROUND",  (0,0), (-1,0), VERT_MOYEN),
            ("TEXTCOLOR",   (0,0), (-1,0), colors.white),
            ("FONTNAME",    (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE",    (0,0), (-1,-1), 9),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[VERT_PALE, colors.white]),
            ("GRID",        (0,0), (-1,-1), 0.5, VERT_CLAIR),
            ("FONTNAME",    (0,1), (0,-1), "Helvetica-Bold"),
            ("TEXTCOLOR",   (0,1), (0,-1), GRIS_TEXTE),
            ("TOPPADDING",  (0,0), (-1,-1), 6),
            ("BOTTOMPADDING",(0,0),(-1,-1), 6),
            ("LEFTPADDING", (0,0), (-1,-1), 8),
        ]))
        story.append(t_sys)

        # ── Modifications manuelles
        dash = etat.get("dashboard", {})
        manuelles = []
        if isinstance(dash, dict):
            manuelles = [(k, v) for k, v in dash.items()
                        if isinstance(v, dict) and v.get("modifie_manuellement")]

        if manuelles:
            story.append(Spacer(1, 20))
            story.append(Paragraph("MODIFICATIONS MANUELLES", s_h1))
            story.append(Spacer(1, 8))
            story.append(Paragraph(
                "Les valeurs suivantes ont été modifiées manuellement par rapport à l'analyse IA :",
                s_body))
            story.append(Spacer(1, 6))

            mod_data = [["Champ", "Valeur actuelle", "Valeur IA initiale", "Horodatage"]]
            for k, v in manuelles:
                hist = v.get("historique", [{}])
                prec = hist[-1].get("valeur_precedente", "?") if hist else "?"
                ts_mod = hist[-1].get("timestamp", "?")[:16].replace("T", " ") if hist else "?"
                mod_data.append([k, str(v.get("valeur")), str(prec), ts_mod])

            t_mod = Table(mod_data, colWidths=[4.5*cm, 4*cm, 4*cm, 4*cm])
            t_mod.setStyle(TableStyle([
                ("BACKGROUND",  (0,0), (-1,0), colors.HexColor("#F57F17")),
                ("TEXTCOLOR",   (0,0), (-1,0), colors.white),
                ("FONTNAME",    (0,0), (-1,0), "Helvetica-Bold"),
                ("FONTSIZE",    (0,0), (-1,-1), 8),
                ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.HexColor("#FFF8E1"), colors.white]),
                ("GRID",        (0,0), (-1,-1), 0.5, colors.HexColor("#FFB300")),
                ("TOPPADDING",  (0,0), (-1,-1), 5),
                ("BOTTOMPADDING",(0,0),(-1,-1), 5),
                ("LEFTPADDING", (0,0), (-1,-1), 6),
            ]))
            story.append(t_mod)

        # ── Note de bas de page
        story.append(Spacer(1, 30))
        story.append(HRFlowable(width="100%", thickness=1, color=VERT_CLAIR, spaceAfter=8))
        story.append(Paragraph(
            "Rapport généré par l'outil bas carbone OTEIS — "
            "Valeurs estimatives APS/APD — Sources : ADEME Base Carbone v23.1, INIES 2023, RE2020 — "
            f"Généré le {datetime.now().strftime('%d/%m/%Y à %H:%M')}",
            s_small))

        doc.build(story)
        return chemin

    # ─────────────────────────────────────────
    #  Export PowerBI (JSON)
    # ─────────────────────────────────────────

    def _export_powerbi(self, etat: dict, slug: str, ts: str) -> Path:
        """
        Génère un JSON structuré optimisé pour Power BI Desktop.
        Trois tables : projet, indicateurs, re2020.
        """
        projet = etat.get("projet", etat)
        bilan  = etat.get("bilan", {})
        dash   = etat.get("dashboard", {})

        # Table 1 : dimensions projet
        table_projet = {
            "table_name": "Projet",
            "rows": [{
                "nom_projet":       projet.get("nom_projet", "—"),
                "maitre_ouvrage":   projet.get("maitre_ouvrage", ""),
                "localisation":     projet.get("localisation", ""),
                "type_batiment":    projet.get("type_batiment", ""),
                "surface_m2":       projet.get("surface_plancher", 0),
                "nb_niveaux":       projet.get("nb_niveaux", 0),
                "zone_climatique":  projet.get("zone_climatique", ""),
                "annee_livraison":  projet.get("annee_livraison", ""),
                "chauffage":        projet.get("systeme_cvc", {}).get("chauffage", ""),
                "ventilation":      projet.get("systeme_cvc", {}).get("ventilation", ""),
                "ecs":              projet.get("systeme_cvc", {}).get("ecs", ""),
                "enr":              ", ".join(projet.get("enr", [])),
                "date_rapport":     datetime.now().isoformat(),
            }]
        }

        # Table 2 : indicateurs carbone (une ligne par indicateur)
        table_indicateurs = {
            "table_name": "Indicateurs",
            "rows": [
                {"indicateur": "Ic_énergie",  "valeur": bilan.get("ic_energie", 0),  "unite": "kgCO2eq/m2.an", "lot": "B6 - Énergie"},
                {"indicateur": "Ic_bâtiment", "valeur": bilan.get("ic_batiment", 0), "unite": "kgCO2eq/m2.an", "lot": "A1-A5 - Produits"},
                {"indicateur": "Ic_total",    "valeur": bilan.get("ic_total", 0),    "unite": "kgCO2eq/m2.an", "lot": "Total"},
                {"indicateur": "Cep",         "valeur": bilan.get("cep", 0),          "unite": "kWh_ep/m2.an",  "lot": "Énergie"},
                {"indicateur": "Bbio",        "valeur": bilan.get("bbio", 0),         "unite": "pts",           "lot": "Bioclimatique"},
                {"indicateur": "Ic_total_projet", "valeur": round(bilan.get("ic_total", 0) * projet.get("surface_plancher", 0) / 1000, 1), "unite": "tCO2", "lot": "Projet"},
            ]
        }

        # Table 3 : RE2020
        re2020 = bilan.get("conformite_re2020", {}).get("niveaux", {})
        table_re2020 = {
            "table_name": "RE2020",
            "rows": [
                {
                    "annee_seuil":    annee,
                    "seuil_kgco2":    v.get("seuil_kgco2_m2_an", v.get("seuil", 0)),
                    "ic_energie":     bilan.get("ic_energie", 0),
                    "conforme":       v.get("conforme", False),
                    "conforme_label": "Conforme" if v.get("conforme") else "Non conforme",
                    "marge":          v.get("marge", 0),
                }
                for annee, v in re2020.items()
            ]
        }

        # Table 4 : postes détaillés
        postes_raw = bilan.get("postes", [])
        if isinstance(postes_raw, dict):
            postes_list = [dict(nom=k, lot=k, **v) if isinstance(v, dict) else {"nom": k, "lot": k} for k, v in postes_raw.items()]
        else:
            postes_list = [p for p in postes_raw if isinstance(p, dict)]
        table_postes = {
            "table_name": "PostesCarbone",
            "rows": [
                {
                    "nom":  p.get("nom", ""),
                    "lot":  p.get("lot", ""),
                    "co2_m2_an": p.get("valeur_kgco2_m2_an", p.get("co2_m2", 0)),
                    "kwh_ep_m2": p.get("valeur_kwh_ep_m2", 0),
                    "source":    p.get("source", ""),
                }
                for p in postes_list
            ]
        }

        # Table 5 : modifications manuelles
        manuelles = []
        if isinstance(dash, dict):
            for k, v in dash.items():
                if isinstance(v, dict) and v.get("modifie_manuellement"):
                    hist = v.get("historique", [{}])
                    manuelles.append({
                        "champ":              k,
                        "valeur_actuelle":    str(v.get("valeur")),
                        "valeur_precedente":  str(hist[-1].get("valeur_precedente", "")) if hist else "",
                        "timestamp":          hist[-1].get("timestamp", "") if hist else "",
                    })

        table_modifications = {
            "table_name": "Modifications",
            "rows": manuelles
        }

        powerbi_data = {
            "_meta": {
                "source":       "OTEIS Outil Bas Carbone",
                "version":      "1.0",
                "genere_le":    datetime.now().isoformat(),
                "projet":       projet.get("nom_projet", "—"),
                "instructions": "Importer ce JSON dans Power BI Desktop via 'Obtenir des données > JSON'"
            },
            "tables": [
                table_projet,
                table_indicateurs,
                table_re2020,
                table_postes,
                table_modifications,
            ]
        }

        chemin = self.dossier_sortie / f"powerbi_{slug}_{ts}.json"
        with open(chemin, "w", encoding="utf-8") as f:
            json.dump(powerbi_data, f, ensure_ascii=False, indent=2)

        return chemin

    # ─────────────────────────────────────────
    #  Fallback JSON
    # ─────────────────────────────────────────

    def _export_json_fallback(self, etat: dict, slug: str, ts: str, fmt: str) -> Path:
        """Exporte en JSON si la lib cible n'est pas disponible."""
        chemin = self.dossier_sortie / f"rapport_{slug}_{ts}_{fmt}_fallback.json"
        with open(chemin, "w", encoding="utf-8") as f:
            json.dump(etat, f, ensure_ascii=False, indent=2)
        return chemin
