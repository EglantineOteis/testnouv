"""
ExcelHandler — gère la génération et mise à jour du fichier Excel de calcul.

Fonctionne avec openpyxl. Si openpyxl n'est pas installé,
retourne des données JSON exploitables par le dashboard.
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Any
import copy


class ExcelHandler:
    """Remplit et met à jour le fichier Excel de calcul carbone."""

    def __init__(self, template_path: Path):
        self.template_path = template_path
        self.output_dir = template_path.parent / "projets"
        self.output_dir.mkdir(exist_ok=True)

        # État interne du dashboard (clé=champ, valeur={valeur, source, modifie_manuellement})
        self._etat_dashboard: dict[str, Any] = {}

    # ─────────────────────────────────────────────
    #  Remplissage Excel depuis les données projet
    # ─────────────────────────────────────────────

    def remplir(self, donnees: dict, nom_sortie: str = "calcul_projet") -> Path:
        """
        Remplit le fichier Excel et retourne son chemin.
        Si openpyxl n'est pas dispo, crée un fichier JSON équivalent.
        """
        # Initialise l'état du dashboard
        self._etat_dashboard = self._donnees_vers_dashboard(donnees)

        try:
            import openpyxl
            return self._remplir_excel(donnees, nom_sortie, openpyxl)
        except ImportError:
            return self._remplir_json(donnees, nom_sortie)

    def _remplir_json(self, donnees: dict, nom_sortie: str) -> Path:
        """Fallback JSON si openpyxl n'est pas disponible."""
        chemin = self.output_dir / f"{nom_sortie}_{datetime.now().strftime('%Y%m%d_%H%M')}.json"
        with open(chemin, "w", encoding="utf-8") as f:
            json.dump({
                "projet": donnees,
                "dashboard": self._etat_dashboard,
                "genere_le": datetime.now().isoformat()
            }, f, ensure_ascii=False, indent=2)
        return chemin

    def _remplir_excel(self, donnees: dict, nom_sortie: str, openpyxl) -> Path:
        """Remplit un fichier Excel avec les données du projet."""
        # Charge le template ou crée un nouveau classeur
        if self.template_path.exists():
            wb = openpyxl.load_workbook(self.template_path)
        else:
            wb = openpyxl.Workbook()

        # Feuille "Données projet"
        ws_projet = wb.active
        ws_projet.title = "Données projet"
        self._ecrire_feuille_projet(ws_projet, donnees)

        # Feuille "Calcul carbone"
        ws_calcul = wb.create_sheet("Calcul carbone")
        self._ecrire_feuille_calcul(ws_calcul, donnees)

        # Feuille "Dashboard"
        ws_dash = wb.create_sheet("Dashboard")
        self._ecrire_feuille_dashboard(ws_dash, self._etat_dashboard)

        chemin = self.output_dir / f"{nom_sortie}_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
        wb.save(chemin)
        return chemin

    def _ecrire_feuille_projet(self, ws, donnees: dict):
        ws["A1"] = "DONNÉES PROJET"
        ws["A2"] = "Généré automatiquement — modifiable"

        lignes = [
            ("Nom du projet",         donnees.get("nom_projet", "")),
            ("Maître d'ouvrage",      donnees.get("maitre_ouvrage", "")),
            ("Localisation",          donnees.get("localisation", "")),
            ("Type de bâtiment",      donnees.get("type_batiment", "")),
            ("Surface plancher (m²)", donnees.get("surface_plancher", 0)),
            ("Nombre de niveaux",     donnees.get("nb_niveaux", 1)),
            ("Zone climatique",       donnees.get("zone_climatique", "H1")),
            ("Année livraison",       donnees.get("annee_livraison", "")),
            ("Système chauffage",     donnees.get("systeme_cvc", {}).get("chauffage", "")),
            ("Système ventilation",   donnees.get("systeme_cvc", {}).get("ventilation", "")),
            ("ENR",                   ", ".join(donnees.get("enr", []))),
        ]

        for i, (label, valeur) in enumerate(lignes, start=4):
            ws[f"A{i}"] = label
            ws[f"B{i}"] = valeur

    def _ecrire_feuille_calcul(self, ws, donnees: dict):
        ws["A1"] = "CALCUL CARBONE — NE PAS MODIFIER LES FORMULES"
        ws["A2"] = "Les cellules en jaune peuvent être ajustées manuellement"

    def _ecrire_feuille_dashboard(self, ws, etat: dict):
        ws["A1"] = "DASHBOARD — TOUTES LES VALEURS SONT MODIFIABLES"
        for i, (cle, cell) in enumerate(etat.items(), start=3):
            ws[f"A{i}"] = cell.get("label", cle)
            ws[f"B{i}"] = cell.get("valeur")
            ws[f"C{i}"] = cell.get("unite", "")
            ws[f"D{i}"] = "Manuel" if cell.get("modifie_manuellement") else "IA"
            ws[f"E{i}"] = cell.get("source", "")

    # ─────────────────────────────────────────────
    #  Mise à jour du dashboard
    # ─────────────────────────────────────────────

    def mettre_a_jour_dashboard(self, modifications: dict, source: str = "manuelle") -> dict:
        """
        Met à jour des champs du dashboard.
        Marque les modifications manuelles pour traçabilité.
        """
        etat = copy.deepcopy(self._etat_dashboard)

        for champ, nouvelle_valeur in modifications.items():
            if champ in etat:
                ancienne = etat[champ]["valeur"]
                etat[champ]["valeur"] = nouvelle_valeur
                etat[champ]["modifie_manuellement"] = (source == "manuelle")
                etat[champ]["historique"] = etat[champ].get("historique", [])
                etat[champ]["historique"].append({
                    "valeur_precedente": ancienne,
                    "nouvelle_valeur": nouvelle_valeur,
                    "source": source,
                    "timestamp": datetime.now().isoformat()
                })
            else:
                # Nouveau champ
                etat[champ] = {
                    "label": champ,
                    "valeur": nouvelle_valeur,
                    "unite": "",
                    "source": source,
                    "modifie_manuellement": (source == "manuelle"),
                    "historique": []
                }

        self._etat_dashboard = etat
        return etat

    # ─────────────────────────────────────────────
    #  Conversion données → état dashboard
    # ─────────────────────────────────────────────

    def _donnees_vers_dashboard(self, donnees: dict) -> dict:
        """Construit l'état initial du dashboard depuis les données projet."""

        def cell(label: str, valeur, unite: str = "", source: str = "dossier client"):
            return {
                "label": label,
                "valeur": valeur,
                "unite": unite,
                "source": source,
                "modifie_manuellement": False,
                "historique": []
            }

        cvc = donnees.get("systeme_cvc", {})
        return {
            # Identité projet
            "nom_projet":       cell("Nom du projet",       donnees.get("nom_projet", "")),
            "maitre_ouvrage":   cell("Maître d'ouvrage",    donnees.get("maitre_ouvrage", "")),
            "localisation":     cell("Localisation",        donnees.get("localisation", "")),
            "type_batiment":    cell("Type de bâtiment",    donnees.get("type_batiment", "")),
            "surface_plancher": cell("Surface plancher",    donnees.get("surface_plancher", 0), "m²"),
            "nb_niveaux":       cell("Nombre de niveaux",   donnees.get("nb_niveaux", 1)),
            "zone_climatique":  cell("Zone climatique",     donnees.get("zone_climatique", "H1")),
            # Systèmes
            "cvc_chauffage":    cell("Chauffage",           cvc.get("chauffage", ""), source="IA"),
            "cvc_ventilation":  cell("Ventilation",         cvc.get("ventilation", ""), source="IA"),
            "cvc_ecs":          cell("ECS",                 cvc.get("ecs", ""), source="IA"),
            "enr":              cell("ENR",                 ", ".join(donnees.get("enr", [])), source="IA"),
            # Résultats carbone (seront mis à jour après calcul)
            "ic_energie":       cell("Ic énergie",          0.0, "kgCO2eq/m².an", source="IA"),
            "ic_batiment":      cell("Ic bâtiment",         0.0, "kgCO2eq/m².an", source="IA"),
            "ic_total":         cell("Ic total",            0.0, "kgCO2eq/m².an", source="IA"),
            "conso_ep":         cell("Consommation Ep",     0.0, "kWh_ep/m².an",  source="IA"),
            "conso_ef":         cell("Consommation Ef",     0.0, "kWh_ef/m².an",  source="IA"),
            "niveau_re2020":    cell("Niveau RE2020 atteint", None, source="IA"),
        }
