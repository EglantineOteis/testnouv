"""
Serveur MCP - Outil Bas Carbone Avant-Projet (APS/APD)
Stage OTEIS - Conception bas carbone

Ce serveur expose les outils MCP pour :
  - Lire et parser les dossiers clients
  - Remplir automatiquement l'Excel de calcul
  - Calculer les bilans carbone/énergie
  - Mettre à jour le dashboard
  - Exporter les rapports
"""

import json
import os
import sys
from pathlib import Path
from typing import Any

# MCP SDK
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Tool,
    TextContent,
    CallToolResult,
)

# Modules internes
sys.path.insert(0, str(Path(__file__).parent.parent))
from excel_module.excel_handler import ExcelHandler
from calcul_carbone.moteur_calcul import MoteurCalcul
from mcp_server.parseur_dossier import ParseurDossier

# ─────────────────────────────────────────────
#  Initialisation
# ─────────────────────────────────────────────

app = Server("outil-bas-carbone")

DATA_DIR = Path(__file__).parent.parent / "data"
EXCEL_TEMPLATE = DATA_DIR / "template_calcul.xlsx"
BASES_DIR = DATA_DIR / "bases"

excel_handler = ExcelHandler(EXCEL_TEMPLATE)
moteur = MoteurCalcul(BASES_DIR)
parseur = ParseurDossier()

# ─────────────────────────────────────────────
#  Définition des outils MCP
# ─────────────────────────────────────────────

@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="lire_dossier_client",
            description=(
                "Lit et parse un dossier client (PDF, JSON, texte). "
                "Extrait : nom projet, surface, systèmes CVC, "
                "matériaux, localisation, type de bâtiment."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "chemin_dossier": {
                        "type": "string",
                        "description": "Chemin vers le dossier ou fichier client"
                    },
                    "format": {
                        "type": "string",
                        "enum": ["pdf", "json", "texte", "auto"],
                        "description": "Format du fichier (auto = détection automatique)",
                        "default": "auto"
                    }
                },
                "required": ["chemin_dossier"]
            }
        ),

        Tool(
            name="remplir_excel",
            description=(
                "Remplit automatiquement le fichier Excel de calcul "
                "avec les données du projet. Retourne le chemin du fichier généré."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "donnees_projet": {
                        "type": "object",
                        "description": "Données du projet issues de lire_dossier_client"
                    },
                    "nom_fichier_sortie": {
                        "type": "string",
                        "description": "Nom du fichier Excel de sortie (sans extension)",
                        "default": "calcul_projet"
                    }
                },
                "required": ["donnees_projet"]
            }
        ),

        Tool(
            name="calculer_bilan_carbone",
            description=(
                "Calcule le bilan carbone et énergie du projet. "
                "Utilise les bases ADENE, INIES, OTEIS. "
                "Retourne : kgCO2, kWh, comparaison variantes, détail par poste."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "donnees_projet": {
                        "type": "object",
                        "description": "Données du projet"
                    },
                    "variantes": {
                        "type": "array",
                        "items": {"type": "object"},
                        "description": "Liste des variantes à comparer (optionnel)",
                        "default": []
                    }
                },
                "required": ["donnees_projet"]
            }
        ),

        Tool(
            name="mettre_a_jour_dashboard",
            description=(
                "Met à jour l'état du dashboard avec de nouvelles valeurs. "
                "Supporte les modifications manuelles (tracées comme 'saisie manuelle'). "
                "Retourne l'état complet du dashboard mis à jour."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "modifications": {
                        "type": "object",
                        "description": "Dictionnaire {champ: nouvelle_valeur} des modifications",
                        "additionalProperties": True
                    },
                    "source": {
                        "type": "string",
                        "enum": ["ia", "manuelle"],
                        "description": "Origine de la modification",
                        "default": "manuelle"
                    }
                },
                "required": ["modifications"]
            }
        ),

        Tool(
            name="comparer_variantes",
            description=(
                "Compare plusieurs variantes techniques (systèmes CVC, ENR, matériaux). "
                "Retourne un tableau comparatif avec scores carbone, énergie, coût."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "variantes": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "nom": {"type": "string"},
                                "systeme_cvc": {"type": "string"},
                                "enr": {"type": "array", "items": {"type": "string"}},
                                "isolation": {"type": "object"}
                            }
                        },
                        "description": "Liste des variantes à comparer"
                    },
                    "criteres": {
                        "type": "array",
                        "items": {
                            "type": "string",
                            "enum": ["carbone", "energie", "cout", "re2020"]
                        },
                        "description": "Critères de comparaison",
                        "default": ["carbone", "energie", "re2020"]
                    }
                },
                "required": ["variantes"]
            }
        ),

        Tool(
            name="exporter_rapport",
            description=(
                "Exporte le rapport final du projet. "
                "Formats disponibles : Excel, PDF, PowerBI (JSON)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "etat_dashboard": {
                        "type": "object",
                        "description": "État actuel du dashboard"
                    },
                    "format": {
                        "type": "string",
                        "enum": ["excel", "pdf", "powerbi"],
                        "default": "excel"
                    },
                    "nom_projet": {
                        "type": "string",
                        "description": "Nom du projet pour le nom de fichier"
                    }
                },
                "required": ["etat_dashboard", "nom_projet"]
            }
        ),

        Tool(
            name="interroger_base",
            description=(
                "Interroge les bases de données carbone (ADENE, INIES, OTEIS). "
                "Retourne les facteurs d'émission et données de référence."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "terme": {
                        "type": "string",
                        "description": "Matériau, équipement ou système à rechercher"
                    },
                    "base": {
                        "type": "string",
                        "enum": ["adene", "inies", "oteis", "toutes"],
                        "default": "toutes"
                    },
                    "unite": {
                        "type": "string",
                        "enum": ["kgCO2_eq", "kWh_ep", "les_deux"],
                        "default": "les_deux"
                    }
                },
                "required": ["terme"]
            }
        ),
    ]


# ─────────────────────────────────────────────
#  Implémentation des outils
# ─────────────────────────────────────────────

@app.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> CallToolResult:

    try:
        if name == "lire_dossier_client":
            resultat = parseur.lire(
                chemin=arguments["chemin_dossier"],
                format=arguments.get("format", "auto")
            )
            return CallToolResult(
                content=[TextContent(
                    type="text",
                    text=json.dumps(resultat, ensure_ascii=False, indent=2)
                )]
            )

        elif name == "remplir_excel":
            chemin_excel = excel_handler.remplir(
                donnees=arguments["donnees_projet"],
                nom_sortie=arguments.get("nom_fichier_sortie", "calcul_projet")
            )
            return CallToolResult(
                content=[TextContent(
                    type="text",
                    text=json.dumps({
                        "statut": "ok",
                        "fichier": str(chemin_excel),
                        "message": f"Excel généré : {chemin_excel.name}"
                    }, ensure_ascii=False)
                )]
            )

        elif name == "calculer_bilan_carbone":
            bilan = moteur.calculer(
                donnees=arguments["donnees_projet"],
                variantes=arguments.get("variantes", [])
            )
            return CallToolResult(
                content=[TextContent(
                    type="text",
                    text=json.dumps(bilan, ensure_ascii=False, indent=2)
                )]
            )

        elif name == "mettre_a_jour_dashboard":
            nouvel_etat = excel_handler.mettre_a_jour_dashboard(
                modifications=arguments["modifications"],
                source=arguments.get("source", "manuelle")
            )
            return CallToolResult(
                content=[TextContent(
                    type="text",
                    text=json.dumps(nouvel_etat, ensure_ascii=False, indent=2)
                )]
            )

        elif name == "comparer_variantes":
            comparaison = moteur.comparer_variantes(
                variantes=arguments["variantes"],
                criteres=arguments.get("criteres", ["carbone", "energie", "re2020"])
            )
            return CallToolResult(
                content=[TextContent(
                    type="text",
                    text=json.dumps(comparaison, ensure_ascii=False, indent=2)
                )]
            )

        elif name == "exporter_rapport":
            from exports.exporteur import Exporteur
            exporteur = Exporteur()
            chemin = exporteur.exporter(
                etat=arguments["etat_dashboard"],
                format=arguments.get("format", "excel"),
                nom=arguments["nom_projet"]
            )
            return CallToolResult(
                content=[TextContent(
                    type="text",
                    text=json.dumps({
                        "statut": "ok",
                        "fichier": str(chemin)
                    }, ensure_ascii=False)
                )]
            )

        elif name == "interroger_base":
            resultats = moteur.interroger_base(
                terme=arguments["terme"],
                base=arguments.get("base", "toutes"),
                unite=arguments.get("unite", "les_deux")
            )
            return CallToolResult(
                content=[TextContent(
                    type="text",
                    text=json.dumps(resultats, ensure_ascii=False, indent=2)
                )]
            )

        else:
            raise ValueError(f"Outil inconnu : {name}")

    except Exception as e:
        return CallToolResult(
            content=[TextContent(
                type="text",
                text=json.dumps({
                    "erreur": str(e),
                    "outil": name
                }, ensure_ascii=False)
            )],
            isError=True
        )


# ─────────────────────────────────────────────
#  Point d'entrée
# ─────────────────────────────────────────────

async def main():
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream, app.create_initialization_options())


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
