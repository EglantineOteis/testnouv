"""Module Calcul Carbone"""
