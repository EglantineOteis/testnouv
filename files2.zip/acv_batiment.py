"""
ACV_Batiment — Analyse du Cycle de Vie simplifiée pour APS/APD.

Calcule les indicateurs RE2020 :
  - Ic_énergie   : impact GES lié à l'énergie en exploitation
  - Ic_bâtiment  : impact GES lié aux produits et équipements
  - Bbio          : besoin bioclimatique (estimé)
  - Cep           : consommation énergie primaire

Périmètre RE2020 Lot CVC / ENR / Enveloppe.
"""

import json
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Optional
import math


# ─────────────────────────────────────────────
#  Structures de données
# ─────────────────────────────────────────────

@dataclass
class PosteCarbone:
    nom: str
    lot: str                        # "énergie" | "bâtiment" | "enr"
    valeur_kgco2_m2_an: float
    valeur_kwh_ep_m2: float = 0.0
    source: str = ""
    modifie_manuellement: bool = False
    note: str = ""

    def to_dict(self):
        return asdict(self)


@dataclass
class BilanCarbone:
    # Indicateurs principaux RE2020
    ic_energie: float = 0.0          # kgCO2eq/m².an
    ic_batiment: float = 0.0         # kgCO2eq/m².an
    ic_total: float = 0.0            # = ic_energie + ic_batiment
    cep: float = 0.0                 # kWh_ep/m².an (Cep)
    cep_nr: float = 0.0              # kWh_ep/m².an non renouvelable
    bbio: float = 0.0                # besoin bioclimatique (estimé)

    # Détail par poste
    postes: list = field(default_factory=list)

    # Conformité
    conformite_re2020: dict = field(default_factory=dict)

    # Méta
    surface_m2: float = 0.0
    ic_total_projet_tco2: float = 0.0
    sources: list = field(default_factory=list)

    def to_dict(self):
        d = asdict(self)
        d["postes"] = [p for p in d["postes"]]
        return d


# ─────────────────────────────────────────────
#  Calcul ACV
# ─────────────────────────────────────────────

class ACVBatiment:
    """
    Analyse du cycle de vie simplifiée.
    Couvre les modules RE2020 : A1-A5, B6, C
    """

    # Facteurs de conversion énergie primaire (non renouvelable)
    CEP_COEFFICIENTS = {
        "electricite":  2.3,    # coefficient énergie primaire réseau national
        "gaz":          1.0,
        "fioul":        1.0,
        "bois":         0.6,
        "reseau_chaud": 0.77,
    }

    # Facteurs GES (kgCO2eq/kWh_ef)
    GES_ENERGIE = {
        "electricite":  0.0485,
        "gaz":          0.227,
        "fioul":        0.324,
        "bois":         0.030,
        "reseau_chaud": 0.110,
    }

    def __init__(self, bases_dir: Path):
        self.bases_dir = bases_dir
        self._facteurs = self._charger_facteurs()

    def _charger_facteurs(self) -> dict:
        p = self.bases_dir / "facteurs_emission.json"
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8"))
        return {}

    # ── Calcul principal ──────────────────────

    def calculer_bilan(self, donnees: dict, variantes: list = None) -> BilanCarbone:
        surface = float(donnees.get("surface_plancher", 1000))
        nb_niveaux = int(donnees.get("nb_niveaux", 3))
        zone = donnees.get("zone_climatique", "H1")
        type_bat = donnees.get("type_batiment", "bureaux")

        bilan = BilanCarbone(surface_m2=surface)
        postes = []

        # ── Module B6 : Ic_énergie ───────────
        postes_energie = self._calculer_postes_energie(donnees, zone)
        ic_energie_total = sum(p.valeur_kgco2_m2_an for p in postes_energie)
        cep_total = sum(p.valeur_kwh_ep_m2 for p in postes_energie)
        postes.extend(postes_energie)

        # ── Modules A1-A5 : Ic_bâtiment ─────
        postes_bat = self._calculer_postes_batiment(donnees, surface, nb_niveaux)
        ic_bat_total = sum(p.valeur_kgco2_m2_an for p in postes_bat)
        postes.extend(postes_bat)

        # ── ENR : crédit carbone ─────────────
        postes_enr = self._calculer_postes_enr(donnees, surface, nb_niveaux)
        credit_enr = sum(p.valeur_kgco2_m2_an for p in postes_enr)  # négatif = crédit
        cep_enr    = sum(p.valeur_kwh_ep_m2   for p in postes_enr)
        postes.extend(postes_enr)

        # ── Bbio estimé ─────────────────────
        bbio = self._estimer_bbio(donnees, zone)

        # ── Consolidation ───────────────────
        bilan.ic_energie  = round(ic_energie_total + credit_enr, 2)
        bilan.ic_batiment = round(ic_bat_total, 2)
        bilan.ic_total    = round(bilan.ic_energie + bilan.ic_batiment, 2)
        bilan.cep         = round(cep_total + cep_enr, 1)
        bilan.cep_nr      = round(cep_total * 0.85, 1)   # estimation 85% non-renouvelable
        bilan.bbio        = round(bbio, 0)
        bilan.postes      = [p.to_dict() for p in postes]
        bilan.ic_total_projet_tco2 = round(bilan.ic_total * surface / 1000, 1)

        # ── Conformité RE2020 ────────────────
        bilan.conformite_re2020 = self._verifier_conformite(bilan, donnees)

        bilan.sources = [
            "ADEME — Base Carbone v23.1",
            "INIES — Données environnementales FDES/PEP 2023",
            "RE2020 — Arrêté du 4 août 2021 modifié",
            "OTEIS — Coefficients internes"
        ]

        return bilan

    # ── Postes énergie (B6) ───────────────────

    def _calculer_postes_energie(self, donnees: dict, zone: str) -> list[PosteCarbone]:
        cvc = donnees.get("systeme_cvc", {})
        facteurs_cvc = self._facteurs.get("systemes_cvc", {})
        correction_zone = {"H1": 1.15, "H2": 1.0, "H3": 0.85}.get(zone, 1.0)
        surface = float(donnees.get("surface_plancher", 1000))

        postes = []
        mapping = {
            "chauffage":        ("Chauffage",        1.0),
            "climatisation":    ("Refroidissement",  0.6),
            "ventilation":      ("Ventilation",      1.0),
            "ecs":              ("ECS",               1.0),
        }

        for cle_cvc, (label, facteur_usage) in mapping.items():
            systeme = cvc.get(cle_cvc, "")
            if systeme and systeme in facteurs_cvc:
                f = facteurs_cvc[systeme]
                kwh_ep = f.get("conso_kwhep_m2", 30) * facteur_usage * correction_zone
                co2    = kwh_ep * self.GES_ENERGIE["electricite"]
                postes.append(PosteCarbone(
                    nom=label, lot="énergie",
                    valeur_kgco2_m2_an=round(co2, 3),
                    valeur_kwh_ep_m2=round(kwh_ep, 1),
                    source="INIES / ADEME"
                ))

        # Éclairage (forfait par type de bâtiment)
        eclairage = {"bureaux": 22, "logement": 10, "scolaire": 16}.get(
            donnees.get("type_batiment", "bureaux"), 18)
        postes.append(PosteCarbone(
            nom="Éclairage", lot="énergie",
            valeur_kgco2_m2_an=round(eclairage * self.GES_ENERGIE["electricite"], 3),
            valeur_kwh_ep_m2=float(eclairage),
            source="RT2020 forfait"
        ))

        # Auxiliaires
        postes.append(PosteCarbone(
            nom="Auxiliaires", lot="énergie",
            valeur_kgco2_m2_an=round(8 * self.GES_ENERGIE["electricite"], 3),
            valeur_kwh_ep_m2=8.0,
            source="RT2020 forfait"
        ))

        return postes

    # ── Postes bâtiment (A1-A5) ───────────────

    def _calculer_postes_batiment(self, donnees: dict, surface: float, nb_niveaux: int) -> list[PosteCarbone]:
        postes = []
        duree_vie = 50  # ans — durée de vie conventionnelle RE2020
        facteurs_iso = self._facteurs.get("isolation", {})

        # Surfaces de référence
        s_toiture  = surface / nb_niveaux
        s_murs     = surface * 0.42  # ratio hauteur/surface
        s_plancher = s_toiture

        # ── Structure béton (forfait APS)
        co2_structure = self._co2_structure_beton(surface, nb_niveaux)
        postes.append(PosteCarbone(
            nom="Structure béton + fondations", lot="bâtiment",
            valeur_kgco2_m2_an=round(co2_structure / duree_vie, 3),
            source="INIES — béton C25/30 moyen",
            note=f"Total : {round(co2_structure)} kgCO2/m² amorti {duree_vie} ans"
        ))

        # ── Isolation parois
        isolation = donnees.get("isolation", {})
        surf_map = {"murs": s_murs, "toiture": s_toiture, "plancher_bas": s_plancher}

        for paroi, config in isolation.items():
            mat = config.get("materiau", "")
            ep  = config.get("epaisseur_cm", 20) / 100
            surf = surf_map.get(paroi, surface * 0.2)

            if mat in facteurs_iso:
                f = facteurs_iso[mat]
                masse = surf * ep * f["densite_kg_m3"]
                co2_total = masse * f["co2_kg"]
                co2_m2_an = co2_total / surface / duree_vie

                postes.append(PosteCarbone(
                    nom=f"Isolation — {paroi} ({mat})",
                    lot="bâtiment",
                    valeur_kgco2_m2_an=round(co2_m2_an, 4),
                    source=f["source"],
                    note=f"{round(masse)} kg total, {f['co2_kg']} kgCO2/kg"
                ))

        # ── Menuiseries (forfait)
        sv_pct = donnees.get("surface_vitre_pct", 30) / 100
        s_vitree = s_murs * sv_pct
        co2_menuiserie = s_vitree * 65 / surface / duree_vie  # 65 kgCO2/m² menuiserie alu
        postes.append(PosteCarbone(
            nom="Menuiseries (châssis + vitrage)", lot="bâtiment",
            valeur_kgco2_m2_an=round(co2_menuiserie, 4),
            source="INIES — menuiserie aluminium DIR"
        ))

        # ── CVC fabrication
        cvc = donnees.get("systeme_cvc", {})
        facteurs_cvc = self._facteurs.get("systemes_cvc", {})
        for poste_cvc, systeme in cvc.items():
            if systeme in facteurs_cvc:
                fab = facteurs_cvc[systeme].get("fabrication", 1.5)
                postes.append(PosteCarbone(
                    nom=f"CVC fabrication — {systeme}",
                    lot="bâtiment",
                    valeur_kgco2_m2_an=round(fab / duree_vie * 15, 4),  # durée vie équip 15 ans
                    source="INIES"
                ))

        return postes

    def _co2_structure_beton(self, surface: float, nb_niveaux: int) -> float:
        """Estimation kgCO2/m² de SHON — structure béton APS."""
        # Source : retours OTEIS / INIES béton C25/30
        # ~250 kgCO2/m² de plancher pour R+3, +15% par niveau supplémentaire
        base = 250.0
        facteur_niveaux = 1 + max(0, nb_niveaux - 3) * 0.05
        return base * facteur_niveaux

    # ── ENR (crédit B6) ───────────────────────

    def _calculer_postes_enr(self, donnees: dict, surface: float, nb_niveaux: int) -> list[PosteCarbone]:
        postes = []
        facteurs_enr = self._facteurs.get("enr", {})
        s_toiture = surface / nb_niveaux
        enr_liste = donnees.get("enr", [])

        pv_pct = donnees.get("surface_pv_pct", 40) / 100

        for enr in enr_liste:
            key = enr.lower()
            if key in facteurs_enr:
                f = facteurs_enr[key]

                if key == "photovoltaïque":
                    s_pv = s_toiture * pv_pct
                    prod_kwh_an = f["production_kwh_m2_an"] * s_pv
                    credit_cep  = -prod_kwh_an / surface  # kWh/m².an évité
                    credit_co2  = credit_cep * self.GES_ENERGIE["electricite"]
                    co2_fab_m2  = f["co2_m2"] * s_pv / surface / 25  # amorti 25 ans

                    postes.append(PosteCarbone(
                        nom="ENR — Photovoltaïque (crédit B6)",
                        lot="enr",
                        valeur_kgco2_m2_an=round(credit_co2 - co2_fab_m2, 4),
                        valeur_kwh_ep_m2=round(credit_cep, 2),
                        source="ADEME",
                        note=f"{round(s_pv)} m² PV, {round(prod_kwh_an)} kWh/an produits"
                    ))

                elif key == "solaire thermique":
                    s_st = s_toiture * 0.15
                    prod_kwh_an = f["production_kwh_m2_an"] * s_st
                    credit_cep  = -prod_kwh_an / surface
                    credit_co2  = credit_cep * self.GES_ENERGIE["electricite"]
                    co2_fab_m2  = f["co2_m2"] * s_st / surface / 25

                    postes.append(PosteCarbone(
                        nom="ENR — Solaire thermique (crédit B6)",
                        lot="enr",
                        valeur_kgco2_m2_an=round(credit_co2 - co2_fab_m2, 4),
                        valeur_kwh_ep_m2=round(credit_cep, 2),
                        source="ADEME",
                        note=f"{round(s_st)} m² solaire thermique"
                    ))

        return postes

    # ── Bbio estimé ──────────────────────────

    def _estimer_bbio(self, donnees: dict, zone: str) -> float:
        """
        Estimation du Bbio (besoin bioclimatique) — indicateur RE2020.
        Méthode simplifiée APS basée sur l'enveloppe.
        """
        isolation = donnees.get("isolation", {})
        uw = donnees.get("menuiseries", {}).get("uw", 1.1)
        sv_pct = donnees.get("surface_vitre_pct", 30)

        # Base selon type bâtiment
        base = {"bureaux": 55, "logement": 80, "scolaire": 60}.get(
            donnees.get("type_batiment", "bureaux"), 65)

        # Correction isolation murs
        ep_murs = isolation.get("murs", {}).get("epaisseur_cm", 20)
        if ep_murs >= 30:
            base -= 8
        elif ep_murs >= 20:
            base -= 4

        # Correction menuiseries
        if uw <= 0.9:
            base -= 6
        elif uw <= 1.1:
            base -= 3

        # Correction surface vitrée
        if sv_pct <= 25:
            base -= 4
        elif sv_pct >= 50:
            base += 8

        # Correction zone
        correction = {"H1": 1.1, "H2": 1.0, "H3": 0.9}.get(zone, 1.0)
        return max(20, base * correction)

    # ── Conformité RE2020 ─────────────────────

    def _verifier_conformite(self, bilan: BilanCarbone, donnees: dict) -> dict:
        type_bat = donnees.get("type_batiment", "bureaux").lower()
        seuils_re2020 = self._facteurs.get("seuils_re2020", {})
        seuils = seuils_re2020.get(type_bat, seuils_re2020.get("autres", {}))

        niveaux = {}
        for annee, seuil in seuils.items():
            conforme = bilan.ic_energie <= seuil
            marge = round(seuil - bilan.ic_energie, 2)
            niveaux[annee] = {
                "seuil_kgco2_m2_an": seuil,
                "ic_energie_calcule": bilan.ic_energie,
                "conforme": conforme,
                "marge": marge,
                "marge_pct": round(marge / seuil * 100, 1) if seuil else 0,
                "badge": "✓ CONFORME" if conforme else "✗ NON CONFORME"
            }

        niveau_max = None
        for annee in ["2031", "2028", "2025", "2022"]:
            if annee in niveaux and niveaux[annee]["conforme"]:
                niveau_max = annee
                break

        return {
            "type_batiment": type_bat,
            "niveaux": niveaux,
            "niveau_re2020_atteint": niveau_max,
            "statut_global": "conforme" if niveau_max else "non conforme",
            "ic_energie": bilan.ic_energie,
            "ic_batiment": bilan.ic_batiment,
            "cep": bilan.cep,
            "bbio_estime": bilan.bbio
        }

    # ── Comparaison variantes ─────────────────

    def comparer_variantes(self, variantes: list, criteres: list = None) -> dict:
        """Compare N variantes et retourne tableau + recommandation."""
        if not criteres:
            criteres = ["carbone", "energie", "re2020"]

        resultats = []
        for v in variantes:
            b = self.calculer_bilan(v)
            conformite = b.conformite_re2020

            score_carbone = b.ic_energie  # plus bas = meilleur
            score_energie = b.cep

            resultats.append({
                "nom":            v.get("nom", f"Variante {len(resultats)+1}"),
                "ic_energie":     b.ic_energie,
                "ic_batiment":    b.ic_batiment,
                "ic_total":       b.ic_total,
                "cep":            b.cep,
                "bbio":           b.bbio,
                "niveau_re2020":  conformite.get("niveau_re2020_atteint"),
                "statut_re2020":  conformite.get("statut_global"),
                "niveaux_detail": conformite.get("niveaux", {}),
                "systeme_cvc":    v.get("systeme_cvc", {}),
                "enr":            v.get("enr", []),
                "isolation":      v.get("isolation", {}),
                "_score":         score_carbone * 0.6 + score_energie * 0.4
            })

        # Tri par score composite
        resultats.sort(key=lambda x: x["_score"])
        for i, r in enumerate(resultats):
            r["rang"] = i + 1
            r["recommande"] = (i == 0)

        # Analyse comparative
        if len(resultats) >= 2:
            meilleur = resultats[0]
            moins_bon = resultats[-1]
            gain_co2 = round(moins_bon["ic_energie"] - meilleur["ic_energie"], 2)
            gain_pct  = round(gain_co2 / moins_bon["ic_energie"] * 100, 1) if moins_bon["ic_energie"] else 0

            analyse = {
                "variante_recommandee": meilleur["nom"],
                "gain_co2_vs_pire":     f"{gain_co2} kgCO2/m².an ({gain_pct}%)",
                "critere_principal":    "Ic_énergie minimisé",
                "commentaire": (
                    f"La variante « {meilleur['nom']} » présente le meilleur bilan carbone "
                    f"avec {meilleur['ic_energie']} kgCO2eq/m².an. "
                    f"Elle atteint le seuil RE2020 {meilleur['niveau_re2020'] or 'aucun'}."
                )
            }
        else:
            analyse = {"commentaire": "Ajouter au moins 2 variantes pour une comparaison."}

        return {
            "nb_variantes": len(resultats),
            "criteres": criteres,
            "resultats": resultats,
            "analyse": analyse
        }
