"""Outil Bas Carbone Avant-Projet — Package MCP"""
